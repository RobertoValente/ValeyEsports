const { app, BrowserWindow, ipcMain, dialog, Notification } = require('electron');
let credentialsDb = require('./src/database.json');
ipcMain.setMaxListeners(0);


var mainWindow = null;
async function createWindow() {
    const mainWindow = new BrowserWindow({
        icon: __dirname + "/src/images/logo.png",
        /*width: 800,
        height: 840,
        minHeight: 600,  
        minWidth: 600,
        */
        fullscreen: true,
        title: 'ValeyEsports - Sistema de RFID',
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false,
        }
    });

    //mainWindow.setResizable(false)
   // mainWindow.removeMenu()
    mainWindow.loadFile('src/pages/Login/index.html');
    //mainWindow.loadFile('src/pages/LogsSystem/index.html');

}

// ==================== Página LogsSystem
ipcMain.on('newNotificationLog', (event, data) => {
    switch (data[0]) {
        case 'sucesso':
            let not1 = new Notification({
                title: 'Custom Notification',
                subtitle: 'Subtitle of the Notification',
                body: 'sucesso',
                silent: false,
                icon: 'src/images/logo.png',
                hasReply: true,  
                timeoutType: 'never', 
                replyPlaceholder: 'Reply Here',
                urgency: 'critical',
                closeButtonText: 'Close Button',
                actions: [ {
                    type: 'button',
                    text: 'Show Button'
                }]
            });
            not1.show();
            break;
        case 'erro':
            let not2 = new Notification({
                title: 'Custom Notification',
                subtitle: 'Subtitle of the Notification',
                body: 'erro',
                silent: false,
                icon: 'src/images/logo.png',
                hasReply: true,  
                timeoutType: 'never', 
                replyPlaceholder: 'Reply Here',
                urgency: 'critical',
                closeButtonText: 'Close Button',
                actions: [ {
                    type: 'button',
                    text: 'Show Button'
                }]
            });
            not2.show();
            break;
        case 'f':
            let not3 = new Notification({
                title: 'Custom Notification',
                subtitle: 'Subtitle of the Notification',
                body: 'f',
                silent: false,
                icon: 'src/images/logo.png',
                hasReply: true,  
                timeoutType: 'never', 
                replyPlaceholder: 'Reply Here',
                urgency: 'critical',
                closeButtonText: 'Close Button',
                actions: [ {
                    type: 'button',
                    text: 'Show Button'
                }]
            });
            not3.show();
            break;
        default:
            let not4 = new Notification({
                title: 'Custom Notification',
                subtitle: 'Subtitle of the Notification',
                body: 'default',
                silent: false,
                icon: 'src/images/logo.png',
                hasReply: true,  
                timeoutType: 'never', 
                replyPlaceholder: 'Reply Here',
                urgency: 'critical',
                closeButtonText: 'Close Button',
                actions: [ {
                    type: 'button',
                    text: 'Show Button'
                }]
            });
            not4.show();
            break;
    }
});

// ==================== Página GerirTags
ipcMain.on('confirmAssociateNFC', (event, data) => {
    const mainWindow = BrowserWindow.getFocusedWindow();

    const options = {
        type: 'question',
        buttons: ['Sim', 'Não'],
        title: 'Confirmação',
        message: 'Tem a certeza que pretende associar um cartão a este utilizador?'
    };

    dialog.showMessageBox(mainWindow, options).then(result => {
        if (result.response === 0) {
            mainWindow.setEnabled(false);
    
            const popup = new BrowserWindow({
                icon: __dirname + "/src/images/logo.png",
                width: 450,
                height: 300,
                title: 'ValeyEsports - Associar',
                webPreferences: {
                    nodeIntegration: true,
                    contextIsolation: false,
                    enableRemoteModule: true,
                },
                frame: false
            });

            popup.setResizable(false);
            popup.removeMenu();
            popup.loadFile('./src/pages/ManageNFCUser/index.html');

            popup.webContents.on('did-finish-load', () => {
                popup.webContents.send('userId', data);
            });

            popup.on('close', function () {
                mainWindow.loadFile('src/pages/GerirTags/index.html');
                mainWindow.setEnabled(true);
            });

        } else return;
    });
});

ipcMain.on('confirmRemoveNFC', (event, data) => {
    const mainWindow = BrowserWindow.getFocusedWindow();

    const options = {
        type: 'question',
        buttons: ['Sim', 'Não'],
        title: 'Confirmação',
        message: 'Tem a certeza que pretende remover o cartão associado a este utilizador?'
    };

    dialog.showMessageBox(mainWindow, options).then(result => {
        if (result.response === 0) {
            connection = connectDatabase();

            connection.connect(function(err) {if (err) { console.error("Erro ao conectar na Base de Dados: " + err.stack); return; }});
            
            connection.query(`UPDATE users SET idnfc = null WHERE id = ${data}`, function(err, results, fields) {
                if(err) console.log(err);
                mainWindow.loadFile('src/pages/GerirTags/index.html');
            });
        
            connection.end(function(err) {if (err) { console.error("Erro ao desconectar da Base de Dados: " + err.stack); return; }});
        } else return;
    });
});

// ==================== Página HOME
ipcMain.on('btnGerirTagsClicked', (event) => {
    const mainWindow = BrowserWindow.getFocusedWindow();
    mainWindow.loadFile('./src/pages/GerirTags/index.html');
});

ipcMain.on('btnSistemaLogsClicked', (event) => {
    const mainWindow = BrowserWindow.getFocusedWindow();
    mainWindow.loadFile('./src/pages/LogsSystem/index.html');
});

ipcMain.on('btnLogoutClicked', (event) => {
    const mainWindow = BrowserWindow.getFocusedWindow();
    mainWindow.loadFile('./src/pages/Login/index.html');
});


// ==================== PÁGINA LOGIN
// Retornar Valor da Variável: loggedUserId
ipcMain.handle('get-loggedUserId', (event) => {
    return global.loggedUserId;
});

// Função para Verificar Login
ipcMain.on('verifyAdmLogin', (event, data) => {
    let connection = connectDatabase();
    connection.connect(function(err) {if (err) { console.error("Erro ao conectar na Base de Dados: " + err.stack); return; }});

    connection.query(`SELECT * FROM users WHERE email LIKE '${data[0]}' AND password LIKE md5('${data[1]}') AND idtipo = 1`, function(err, results, fields) {
        if(err) throw err;
        let resultArray = Object.entries(results);

        if(resultArray.length === 1) {
            global.loggedUserId = results[0].id.toString();
            const mainWindow = BrowserWindow.getFocusedWindow();
            mainWindow.loadFile('./src/pages/Home/index.html');
        }
    })
    connection.end(function(err) {if (err) { console.error("Erro ao desconectar da Base de Dados: " + err.stack); return; }});
});

// Setup de uma Conexão à Base de Dados
function connectDatabase() {
    let mysql = require('mysql');
    let connection = mysql.createConnection({
        host: credentialsDb.host,
        user: credentialsDb.user,
        password: credentialsDb.password,
        database: credentialsDb.database
    });

    return connection;
}



app.whenReady().then(createWindow);

app.on('activate', () => {
    if(BrowserWindow.getAllWindows().length === 0) {
        createWindow();
    }
});

app.on('window-all-closed', function () {
    if (process.platform !== 'darwin') app.quit()
});
