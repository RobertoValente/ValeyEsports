let { PythonShell } = require('python-shell');

// ==================== NAV
document.getElementById('menuGerirTags').addEventListener('click', (event) => {
    event.preventDefault();
    ipcRenderer.send('btnGerirTagsClicked', true);
});

document.getElementById('menuSistemaLogs').addEventListener('click', (event) => {
    event.preventDefault();
    ipcRenderer.send('btnSistemaLogsClicked', true);
});

document.getElementById('menuLogout').addEventListener('click', (event) => {
    event.preventDefault();
    ipcRenderer.send('btnLogoutClicked', true);
});

// ==================== Check Btn
document.getElementById('btnTurnOnOffLogsSystem').addEventListener('click', async (event) => {
    event.preventDefault();

    let alertBox = document.getElementById('alertBox');
    let btnElement = document.getElementById('btnTurnOnOffLogsSystem');
    let btnValue = btnElement.value;

    if(btnValue === "0") {
        alertBox.style.display = 'block';
        btnElement.innerHTML = "Desativar";
        btnElement.style.color = '#FEFEFE';
        btnElement.value = "1";

        console.log("Alterou")
        await loopLerTag(true);
    } else {
        await loopLerTag(false);
        console.log("f")

        alertBox.style.display = 'none';
        btnElement.innerHTML = "Ativar";
        btnElement.value = "0";
    }
});

// ==================== Loop Infinito
var processId;
async function loopLerTag(keepGoing) {  
    if(keepGoing) {
        console.log("A ler...")  
        readNFC = new PythonShell('src/pages/LogsSystem/readNFC.py');
        processId = readNFC.childProcess.pid
        await readCard(readNFC);
    } else {
        await process.kill(parseInt(processId), "SIGINT");
    }
}

// ==================== Funcao Ler Tag
async function readCard(readNFC) {
    let connection = mysql.createConnection({
        host: credentialsDb.host,
        user: credentialsDb.user,
        password: credentialsDb.password,
        database: credentialsDb.database
    });

    let valueNFC;
        
    readNFC.on("message", async function(message) {
        valueNFC = message;
        //readNFC.send('0');
        //setTimeout(() => { readNFC.send('0'); console.log("#"), 3000 });
    });
                                                
    readNFC.end(async function(err, code, signal) {
        if(err) {
            console.log(err);
            btnElement.innerHTML = "Ocorreu um Erro!";
            await readNFC.childProcess.kill();
            loopLerTag(false);

        } else {
            if(!valueNFC) return;
            connection.connect(function(err) {if (err) { console.error("Erro ao conectar na Base de Dados: " + err.stack); return; }});

            connection.query(`SELECT id, nome FROM users WHERE idnfc LIKE '${valueNFC}'`, async function(err, results, fields) {
                if(err) throw err;
                let resultArray = Object.entries(results);

                if(resultArray.length === 1) {
                    let nfcIOwnerId = resultArray[0][1].id;
                    connection.query(`INSERT INTO logs(iduser, idtipo) VALUES ('${nfcIOwnerId}','2')`, async function(err, results, fields) {
                        console.log("Inseriru...");
                        console.log(err)
                        //await readNFC.childProcess.kill();
                        //return loopLerTag(true);
                        //Atualizar a tabela apenas

                        try {
                            const { ipcRenderer } = require('electron');
console.log("Criei tabela")

    let mysql = require('mysql');
    let credentialsDb = require('../../database.json');

    let data = [];
    let dataRow;

    let connection = mysql.createConnection({
        host: credentialsDb.host,
        user: credentialsDb.user,
        password: credentialsDb.password,
        database: credentialsDb.database
    });

    connection.connect(function(err) {if (err) { console.error("Erro ao conectar na Base de Dados: " + err.stack); return; }});
    
    connection.query(`SELECT users.nome as nome, users.email as email, tipouser.tipo as tipo, logs.data as data, users.idtipo, logs.iduser, users.id, logs.idtipo  FROM users, tipouser, logs  WHERE logs.idtipo = 2 AND users.id = logs.iduser AND users.idtipo = tipouser.id order by logs.data DESC`, function(err, results, fields) {
        if(err) throw err;
        let resultArray = Object.entries(results);
        if(resultArray.length === 0) return;

        results.forEach(function(user) {
            dataRow = {
                "Nome": user.nome,
                "Email": user.email,
                "Tipo": user.tipo,
                "Data": user.data
            };

            data.push(dataRow)
        });

        $('.GerirTagsTable').DataTable({
            "aaData": data,
            destroy: true,
            searching: false,
            "columns": [{
                "data": "Nome"
            }, {
                "data": "Email"
            },{
                "data": "Tipo"
            },{
                "data": null,
                render: function (data, type, row, meta) {
                    // GMT+0000 (Western European Standard Time)
                    let dataFormated = data['Data'].toString().replace(' GMT+0100 (Western European Summer Time)', '');
                    dataFormated = dataFormated.replace(' GMT+0100 (Hora de verão da Europa Ocidental)', '');
                    return `<span>${dataFormated}</span>`;
                }
            }],
            responsive: true,
            "language": {
                "processing":   "A processar...",
                "lengthMenu":   "Mostrar _MENU_ registos",
                "zeroRecords":  "Não foram encontrados resultados",
                "info":         "Mostrando de _START_ até _END_ de _TOTAL_ registos",
                "infoEmpty":    "Mostrando de 0 até 0 de 0 registos",
                "infoFiltered": "(filtrado de _MAX_ registos no total)",
                "infoPostFix":  "",
                "search":       "Procurar:",
                "url":          "",
                "paginate": {
                    "first":    "Primeiro",
                    "previous": "Anterior ",
                    "next":     " Seguinte",
                    "last":     "Último"
                }
            }
        });
    });

    connection.end(function(err) {if (err) { console.error("Erro ao desconectar da Base de Dados: " + err.stack); return; }});

                        } catch (err) {
                            console.log(err)
                            console.log("FF")
                        }

                        connection.end(function(err) {if (err) { console.error("Erro ao desconectar da Base de Dados: " + err.stack); return; }});
                        await readNFC.childProcess.kill();
                        console.log("passou aqui")
                        sleep(4000);
                        loopLerTag(true);
                    });
                    
                    //ipcRenderer.send('newNotificationLog', ['sucesso', 'nome da pessoa']); //Não Funciona
                } else if(resultArray.length >= 1) {
                    console.log("existe um ou mais utilizadores com este RFID associado");
                    //ipcRenderer.send('newNotificationLog', ['erro', 'Existe mais de um utilizador com este NFC associado!']); //Não Funciona
                    connection.end(function(err) {if (err) { console.error("Erro ao desconectar da Base de Dados: " + err.stack); return; }});
                    await readNFC.childProcess.kill();
                    loopLerTag(true);
                } else if(resultArray.length === 0) {
                    console.log("ninguem tem este RFID associado")
                    //ipcRenderer.send('newNotificationLog', ['f', 'Não existe um utilizador com este NFC associado!']); //Não Funciona
                    connection.end(function(err) {if (err) { console.error("Erro ao desconectar da Base de Dados: " + err.stack); return; }});
                    await readNFC.childProcess.kill();
                    loopLerTag(true);
                }
                
            });
        }
    });
}

function sleep(ms) {
    const date = Date.now();
    let currentDate = null;
    do {
        currentDate = Date.now();
    } while(currentDate - date < ms);
}