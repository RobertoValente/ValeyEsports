const { ipcRenderer } = require('electron');
console.log("Criei tabela")

    let mysql = require('mysql');
    let credentialsDb = require('../../database.json');

    let data = [];
    let dataRow;

    let connection = mysql.createConnection({
        host: credentialsDb.host,
        user: credentialsDb.user,
        password: credentialsDb.password,
        database: credentialsDb.database
    });

    connection.connect(function(err) {if (err) { console.error("Erro ao conectar na Base de Dados: " + err.stack); return; }});
    
    connection.query(`SELECT users.nome as nome, users.email as email, tipouser.tipo as tipo, logs.data as data, users.idtipo, logs.iduser, users.id, logs.idtipo  FROM users, tipouser, logs  WHERE logs.idtipo = 2 AND users.id = logs.iduser AND users.idtipo = tipouser.id order by logs.data DESC`, function(err, results, fields) {
        if(err) throw err;
        let resultArray = Object.entries(results);
        if(resultArray.length === 0) return;

        results.forEach(function(user) {
            dataRow = {
                "Nome": user.nome,
                "Email": user.email,
                "Tipo": user.tipo,
                "Data": user.data
            };

            data.push(dataRow)
        });

        $('.GerirTagsTable').DataTable({
            "aaData": data,
            destroy: true,
            searching: false,
            "columns": [{
                "data": "Nome"
            }, {
                "data": "Email"
            },{
                "data": "Tipo"
            },{
                "data": null,
                render: function (data, type, row, meta) {
                    // GMT+0000 (Western European Standard Time)
                    let dataFormated = data['Data'].toString().replace(' GMT+0100 (Western European Summer Time)', '');
                    dataFormated = dataFormated.replace(' GMT+0100 (Hora de verão da Europa Ocidental)', '');
                    return `<span>${dataFormated}</span>`;
                }
            }],
            responsive: true,
            "language": {
                "processing":   "A processar...",
                "lengthMenu":   "Mostrar _MENU_ registos",
                "zeroRecords":  "Não foram encontrados resultados",
                "info":         "Mostrando de _START_ até _END_ de _TOTAL_ registos",
                "infoEmpty":    "Mostrando de 0 até 0 de 0 registos",
                "infoFiltered": "(filtrado de _MAX_ registos no total)",
                "infoPostFix":  "",
                "search":       "Procurar:",
                "url":          "",
                "paginate": {
                    "first":    "Primeiro",
                    "previous": "Anterior ",
                    "next":     " Seguinte",
                    "last":     "Último"
                }
            }
        });
    });

    connection.end(function(err) {if (err) { console.error("Erro ao desconectar da Base de Dados: " + err.stack); return; }});
