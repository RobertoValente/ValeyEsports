// Script.js -> Home
const { ipcRenderer, BrowserWindow } = require('electron');

// ==================== NAV
document.getElementById('menuGerirTags').addEventListener('click', (event) => {
    event.preventDefault();
    ipcRenderer.send('btnGerirTagsClicked', true);
});

document.getElementById('btnGerirTags').addEventListener('click', (event) => {
    event.preventDefault();
    ipcRenderer.send('btnGerirTagsClicked', true);
});

document.getElementById('menuSistemaLogs').addEventListener('click', (event) => {
    event.preventDefault();
    ipcRenderer.send('btnSistemaLogsClicked', true);
});

document.getElementById('btnSistemaLogs').addEventListener('click', (event) => {
    event.preventDefault();
    ipcRenderer.send('btnSistemaLogsClicked', true);
});

document.getElementById('menuLogout').addEventListener('click', (event) => {
    event.preventDefault();
    ipcRenderer.send('btnLogoutClicked', true);
});

document.getElementById('btnLogout').addEventListener('click', (event) => {
    event.preventDefault();
    ipcRenderer.send('btnLogoutClicked', true);
});