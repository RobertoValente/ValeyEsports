const { ipcRenderer } = require('electron');

$(document).ready(function () {
    let mysql = require('mysql');
    let credentialsDb = require('../../database.json');

    let data = [];
    let dataRow;

    let connection = mysql.createConnection({
        host: credentialsDb.host,
        user: credentialsDb.user,
        password: credentialsDb.password,
        database: credentialsDb.database
    });

    connection.connect(function(err) {if (err) { console.error("Erro ao conectar na Base de Dados: " + err.stack); return; }});

    /* id, nome, email, idnfc (null se não existir)*/
    connection.query(`SELECT id, nome, email, idnfc FROM users`, function(err, results, fields) {
        if(err) throw err;
        let resultArray = Object.entries(results);
        if(resultArray.length === 0) return;

        results.forEach(function(user) {
            if((user.id !== 0) && (user.id !== 1)) {
                dataRow = {
                    "userId": user.id,
                    "Nome": user.nome,
                    "Email": user.email,
                    "NFC": user.idnfc
                };
    
                data.push(dataRow)
            }
        });

        $('.GerirTagsTable').DataTable({
            "aaData": data,
            "columns": [{
                "data": "Nome"
            }, {
                "data": null,
                render: function (data, type, row, meta) {
                    return `<span id="emailUserId${data['userId']}">${data['Email']}</span>`;
                }
            }, {
                "data": null,
                render: function (data, type, row, meta) {
                    if(data['NFC'] === null) {
                        return `<div title="Associar - ${data['userId']}/${data['Nome']}" id="associarNFC"><svg width="20px" height="20px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"/><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"/><g id="SVGRepo_iconCarrier"> <path d="M12 8V16M16 12H8M6 20H18C19.1046 20 20 19.1046 20 18V6C20 4.89543 19.1046 4 18 4H6C4.89543 4 4 4.89543 4 6V18C4 19.1046 4.89543 20 6 20Z" stroke="#19A143" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/> </g></svg></div>`;
                    } else {
                        return `<div title="Remover - ${data['userId']}/${data['Nome']}" id="removerNFC"><svg width="20px" height="20px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="#EA1F2D"><g id="SVGRepo_bgCarrier" stroke-width="0"/><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"/><g id="SVGRepo_iconCarrier"> <title>i</title> <g id="Complete"> <g id="remove-square"> <g> <rect id="_--Rectangle" data-name="--Rectangle" x="2" y="2" width="20" height="20" rx="2" ry="2" fill="none" stroke="#EA1F2D" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/> <line x1="15.5" y1="12" x2="8.5" y2="12" fill="none" stroke="#EA1F2D" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/> </g> </g> </g> </g></svg></div>`;
                    }
                }
            }],
            "createdRow": function(row, data, index) {
                $(row).find('#associarNFC').click(function() { 
                    let userIdSelected = data['userId'];
                    ipcRenderer.send('confirmAssociateNFC', userIdSelected);
                });

                $(row).find('#removerNFC').click(function() {
                    let userIdSelected = data['userId'];
                    ipcRenderer.send('confirmRemoveNFC', userIdSelected);
                });
            },
            responsive: true,
            "language": {
                "processing":   "A processar...",
                "lengthMenu":   "Mostrar _MENU_ registos",
                "zeroRecords":  "Não foram encontrados resultados",
                "info":         "Mostrando de _START_ até _END_ de _TOTAL_ registos",
                "infoEmpty":    "Mostrando de 0 até 0 de 0 registos",
                "infoFiltered": "(filtrado de _MAX_ registos no total)",
                "infoPostFix":  "",
                "search":       "Procurar:",
                "url":          "",
                "paginate": {
                    "first":    "Primeiro",
                    "previous": "Anterior ",
                    "next":     " Seguinte",
                    "last":     "Último"
                }
            }
        });
    });

    connection.end(function(err) {if (err) { console.error("Erro ao desconectar da Base de Dados: " + err.stack); return; }});
});