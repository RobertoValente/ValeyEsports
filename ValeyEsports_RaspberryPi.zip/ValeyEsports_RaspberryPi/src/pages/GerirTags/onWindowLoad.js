window.jQuery = window.$ = require('jquery');
require('datatables.net')(window, $);