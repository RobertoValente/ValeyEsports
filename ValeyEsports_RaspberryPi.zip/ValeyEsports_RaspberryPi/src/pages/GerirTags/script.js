// ==================== NAV
document.getElementById('menuGerirTags').addEventListener('click', (event) => {
    event.preventDefault();
    ipcRenderer.send('btnGerirTagsClicked', true);
});

document.getElementById('menuSistemaLogs').addEventListener('click', (event) => {
    event.preventDefault();
    ipcRenderer.send('btnSistemaLogsClicked', true);
});

document.getElementById('menuLogout').addEventListener('click', (event) => {
    event.preventDefault();
    ipcRenderer.send('btnLogoutClicked', true);
});