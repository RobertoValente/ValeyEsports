// ==================== Restante
const { ipcRenderer } = require('electron');

document.getElementById('btnLogin').addEventListener('click', (event) => {
    event.preventDefault();

    let email = document.getElementById('valueEmail').value;
    let password = document.getElementById('valuePassword').value;

    if(email === '' || password === '') {
        return;
    } else {
        ipcRenderer.send('verifyAdmLogin', [email, password]);
    };
});