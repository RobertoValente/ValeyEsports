// ==================== Restante
const { ipcRenderer } = require('electron');
let userId;
ipcRenderer.on('userId', (event, value) => { userId = value });
let { PythonShell } = require('python-shell');
let mysql = require('mysql');
let credentialsDb = require('../../database.json');
let readNFC = new PythonShell('src/pages/ManageNFCUser/readNFC.py');

document.getElementById('btnReadCancel').addEventListener('click', (event) => {
    event.preventDefault();

    const btnElement = document.getElementById("btnReadCancel");
    const alertElement = document.getElementById("alertBox");

    btnElement.innerHTML = ". . .";
    alertElement.style.display = 'block';
    
    let valueNFC;
    readNFC.on("message", function(message) {
        valueNFC = message;
        btnElement.setAttribute('disabled', 'disabled');
        btnElement.style.filter = 'blur(0.8px)';
        alertElement.style.display = 'none';
        btnElement.innerHTML = "RFID Lido!";
    });

    readNFC.end(function(err, code, signal) {
        if(err) {
            console.log(err);
            btnElement.innerHTML = "Ocorreu um Erro!";
        } else {
            let connection = mysql.createConnection({
                host: credentialsDb.host,
                user: credentialsDb.user,
                password: credentialsDb.password,
                database: credentialsDb.database
            });

            connection.connect(function(err) {if (err) { console.error("Erro ao conectar na Base de Dados: " + err.stack); return; }});

            connection.query(`SELECT id, nome FROM users WHERE idnfc LIKE '${valueNFC}'`, function(err, results, fields) {
                if(err) throw err;
                    let resultArray = Object.entries(results);

                    if(resultArray.length >= 1) {
                        btnElement.innerHTML = "Alguém tem este RFID!";
                    } else {
                        connection.query(`UPDATE users SET idnfc = '${valueNFC}' WHERE id = ${userId}`, function(err, results, fields) {
                            if(err) {
                                console.log(err);
                                btnElement.innerHTML = "Ocorreu um Erro!";
                            } else btnElement.innerHTML = "RFID Associado!";
                        });
                    
                        connection.end(function(err) {if (err) { console.error("Erro ao desconectar da Base de Dados: " + err.stack); return; }});
                    }
            })
        }
        readNFC.childProcess.kill();
    });

});

document.getElementById('btnBackPage').addEventListener('click', (event) => {
    try {
        readNFC.childProcess.kill();
    } catch (err) {
        throw err;
    }
    window.close();
});