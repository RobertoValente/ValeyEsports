#!/usr/bin/env python

import RPi.GPIO as GPIO
from mfrc522 import SimpleMFRC522

reader = SimpleMFRC522()

try:
    checkReaded = False
    while (checkReaded == False):
        idNFC, textNFC = reader.read()
        checkReaded = True
        print(idNFC)
except:
    pass
finally:
    GPIO.cleanup()