<?php
    include('../../scripts/Database/connect.php');
    include('../../scripts/ManageUser/verifyUserNotLog.php');
    $idUser = $_SESSION['userId'];
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/searchTournament.css">
    <link rel="stylesheet" href="../../css/global.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAP - Roberto</title>

    <link href='../../Extras/DataTables/datatables.min.css' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="../../Extras/jquery-3.5.1.min.js"></script>
    <script type="text/javascript" src="../../Extras/DataTables/datatables.min.js"></script>
</head>

<?php 
    include('../components/nav.php');
?>

<body style="background-color: var(--bgColorMain); margin-bottom: 40px">
    <div class="bodySearchTournament">
        <h1 class="pageTitleSearchTournament">Procurar Torneios:</h1>
        <div class="containerSearchTournament">
            <table class="showTournamentsTable" class="display dataTable">
                <thead>
                    <tr>
                        <th style="text-align: center;">Nome</th>
                        <th class="select-filter" style="text-align: center;">Jogo</th>
                        <th style="text-align: center;">Nº Jogadores (P/M)</th>
                        <th style="text-align: center;">&nbsp;</th>

                        <!-- https://datatables.net/forums/discussion/28077/disable-filtering-of-one-or-multiple-columns-select-inputs -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $result = mysqli_query($ligaBD, "SELECT torneios.id, torneios.nome, jogos.jogo, torneios.idjogo, torneios.nMaxParticipantes, torneios.idestado FROM torneios, jogos WHERE jogos.id = torneios.idjogo and torneios.idestado = 0");
                        $row1Length = mysqli_num_rows($result);
                        while($row = mysqli_fetch_array($result)) {
                            $queryNumPlayers = "SELECT idtorneio FROM participantes_torneio where participantes_torneio.idtorneio = ". $row['id'];
                            $resultNumPlayers = mysqli_query($ligaBD, $queryNumPlayers);
                            $lenghtNumPlayers = mysqli_num_rows($resultNumPlayers);
                            echo "<tr>";
                                echo "<td style='text-align: center;'>". $row['nome'] ."</td>"  ;
                                echo "<td style='text-align: center;'>". $row['jogo'] ."</td>";
                                echo "<td style='text-align: center;'>". $lenghtNumPlayers ."/". $row['nMaxParticipantes'] ."</td>";
                                echo "<td style='text-align: center;'>";
                                echo "<a style='text-decoration: none;' href='./detailsTournament.php?torneio=". $row['id'] ."'>Detalhes</a>";
                                echo "</td>";
                            echo "</tr>";
                          }
                    ?>
                </tbody>
            </table>     
        </div>
    </div>
</body>

<script>
    $(document).ready(function(){
        $('.showTournamentsTable').DataTable({
            /*initComplete: function () {
                this.api().columns([1]).every( function () {
                    var column = this;
                    var select = $('<select><option value="a">a</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
    
                            column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                        } );
    
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
            },*/
            rowReorder: {
                selector: 'td:nth-child(4)'
            },
            responsive: true,
            "language": {
                "processing":   "A processar...",
                "lengthMenu":   "Mostrar _MENU_ registos",
                "zeroRecords":  "Não foram encontrados resultados",
                "info":         "Mostrando de _START_ até _END_ de _TOTAL_ registos",
                "infoEmpty":    "Mostrando de 0 até 0 de 0 registos",
                "infoFiltered": "(filtrado de _MAX_ registos no total)",
                "infoPostFix":  "",
                "search":       "Procurar:",
                "url":          "",
                "paginate": {
                    "first":    "Primeiro",
                    "previous": "Anterior",
                    "next":     "Seguinte",
                    "last":     "Último"
                }
            }
        });
    });
</script>

<?php 
    include('../components/footer.php');
?>