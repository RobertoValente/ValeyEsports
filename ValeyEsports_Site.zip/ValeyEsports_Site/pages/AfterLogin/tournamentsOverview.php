<?php
    include('../../scripts/ManageUser/verifyUserNotLog.php');
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/tournamentOverview.css">
    <link rel="stylesheet" href="../../css/global.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAP - Roberto</title>
</head>

<?php 
    include('../components/nav.php');
?>

<body style="background-color: var(--bgColorMain); margin-bottom: 40px">
    <div class="bodyTournamentOverview">

        <div class="containerTournamentOverview" style="height: 65%;">
            <div class="gridElement" style="height: 90%;">
                <span class="labelTxt">MEUS TORNEIOS:</span>
                <div class="tournamentsContentDiv">
                    <?php
                        include('../../scripts/Database/connect.php');
                        $queryMyTournaments = "SELECT id, nome, nMaxParticipantes, idestado FROM torneios where torneios.idcriador = ". $_SESSION['userId'];
                        $resultMyTournaments = mysqli_query($ligaBD, $queryMyTournaments);
                        $lenghtMyTournaments = mysqli_num_rows($resultMyTournaments);
                        if($lenghtMyTournaments == 0) {
                            echo "Não foram encontrados resultados!";
                        } else {
                            while($row = mysqli_fetch_array($resultMyTournaments)){
                                if($row['idestado'] != 3) {
                                    $queryNumPlayers = "SELECT idtorneio FROM participantes_torneio where participantes_torneio.idtorneio = ". $row['id'];
                                    $resultNumPlayers = mysqli_query($ligaBD, $queryNumPlayers);
                                    $lenghtNumPlayers = mysqli_num_rows($resultNumPlayers);

                                    $dotColor = "";
                                    switch($row['idestado']) {
                                        case 0:
                                            $dotColor = "green"; //Não iniciado
                                            break;
                                        case 1: 
                                            $dotColor = "yellow"; //Iniciado
                                            break;
                                        case 2:
                                            $dotColor = "red"; //Terminado
                                            break;
                                        case 3:
                                            $dotColor = "black"; //Eliminado
                                            break;
                                    }

                                    echo '<div class="myTournamentInfo">';
                                        echo '<div class="tournName"><span class="dot" style="height: 0.5rem; width: 0.5rem; background-color: '. $dotColor .'; border-radius: 50%; display: inline-block; vertical-align: middle;"></span> '. $row['nome'] .'</div>';
                                        echo '<div class="tournPlayers">'. $lenghtNumPlayers .'/'. $row['nMaxParticipantes'] .'</div>';
                                        echo '<form action="./manageTournament.php" method="POST">';
                                            echo '<div class="tournBtn"><button type="submit" class="tournBtnCustom" name="tournament['. $row['id'] .']">Gerir</button></div>';
                                        echo '</form>';
                                    echo '</div>';
                                }
                            }
                        }
                    ?>
                </div>
                <a href="./createTournament.php"><button class="buttonDiv">Criar Torneio</button></a>
            </div>
            <div class="gridElement" style="height: 90%;">
                <span class="labelTxt">MINHAS PARTICIPAÇÕES:</span>
                <div class="tournamentsContentDiv">
                    <?php
                        $queryParticipateTournaments = "SELECT idtorneio, iduser FROM participantes_torneio where participantes_torneio.iduser = ". $_SESSION['userId'];
                        $resultParticipateTournaments = mysqli_query($ligaBD, $queryParticipateTournaments);
                        $lenghtParticipateTournaments = mysqli_num_rows($resultParticipateTournaments);
                        if($lenghtParticipateTournaments == 0) {
                            echo "Não foram encontrados resultados!";
                        } else {
                            while($row = mysqli_fetch_array($resultParticipateTournaments)){
                                $queryMyTournaments = "SELECT id, nome, nMaxParticipantes, idestado FROM torneios where torneios.id = ". $row['idtorneio'];
                                $resultMyTournaments = mysqli_query($ligaBD, $queryMyTournaments);
                                while($row2 = mysqli_fetch_array($resultMyTournaments)){
                                    if($row2['idestado'] != 3) {
                                        $queryNumPlayers = "SELECT idtorneio FROM participantes_torneio where participantes_torneio.idtorneio = ". $row['idtorneio'];
                                        $resultNumPlayers = mysqli_query($ligaBD, $queryNumPlayers);
                                        $lenghtNumPlayers = mysqli_num_rows($resultNumPlayers);

                                        $dotColor = "";
                                        switch($row2['idestado']) {
                                            case 0:
                                                $dotColor = "green";
                                                break;
                                            case 1:
                                                $dotColor = "yellow";
                                                break;
                                            case 2:
                                                $dotColor = "red";
                                                break;
                                            case 3:
                                                $dotColor = "black";
                                                break;
                                        }

                                        echo '<div class="myTournamentInfo">';
                                            echo '<div class="tournName"><span class="dot" style="height: 0.5rem; width: 0.5rem; background-color: '. $dotColor .'; border-radius: 50%; display: inline-block; vertical-align: middle;"></span> '. $row2['nome'] .'</div>';
                                            echo '<div class="tournPlayers">'. $lenghtNumPlayers .'/'. $row2['nMaxParticipantes'] .'</div>';
                                            echo '<div class="tournBtn"><a style="text-decoration: none;" href="./detailsTournament.php?torneio='. $row2['id'] .'"><button class="tournBtnCustom">Detalhes</button></a></div>';
                                        echo '</div>';
                                    }
                                }
                            }
                        }
                    ?>
                </div>
                <a href="./searchTournament.php"><button class="buttonDiv" style="margin-bottom: 60px;">Procurar Torneios</button></a>
            </div>
        </div>
    </div>
    
</body>

<?php 
    include('../components/footer.php');
?>