<?php
    include('../../scripts/ManageUser/verifyUserNotLog.php');
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/editProfile.css">
    <link rel="stylesheet" href="../../css/global.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAP - Roberto</title>
</head>

<?php 
    include('../components/nav.php');
?>

<body style="background-color: var(--bgColorMain); margin-bottom: 40px">
    <div class="bodyEditProfile">
        <!--<h1 class="pageTitleEditProfile">Editar Perfil:</h1>-->
        <div class="containerEditProfile" style="overflow-x: auto;">
            <?php
                include('../../scripts/Database/connect.php');
                $queryGetProfileData = "SELECT id, nome, email, idDiscord FROM users where users.id = ". $_SESSION['userId'];
                $result = mysqli_query($ligaBD, $queryGetProfileData);
                $row = mysqli_fetch_array($result);
            ?>
            <!--<br>
            <label class="lblChangeImg">Foto de Perfil: (add bd)</label> <br>
            <a href="#">
                <img title="Alterar Imagem" src="" alt="Foto do seu perfil">
            </a>
            <input class="inputCustom" name="imagem" type="file" accept=".png, .jpg, .jpeg" value=""  placeholder="Abrir files para selecionar ficheiro" required>
            <br>
            <hr> -->
            <form action="../../scripts/ManageUser/userEditProfile.php" method="POST">
                <label class="lblNome">Nome:</label> <br>
                <input class="inputNome" name="nome" type="text" value="<?php echo $row['nome']; ?>">
                <button class="primaryBtnEditProfile" type="submit">Guardar</button>
            </form>
            <hr>
            <label class="lblNome">Email:</label> <br>
            <input class="inputNome" name="email" type="text" value="<?php echo $row['email']; ?>" readOnly = "true" style="cursor: not-allowed" >
            <br>
            <br>            
        </div>
    </div>
    
</body>

<?php 
    include('../components/footer.php');
?>