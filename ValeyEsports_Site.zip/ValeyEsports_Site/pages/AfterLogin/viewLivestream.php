<?php
    include('../../scripts/ManageUser/verifyUserNotLog.php');
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/editProfile.css">
    <link rel="stylesheet" href="../../css/global.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAP - Roberto</title>
</head>

<?php 
    include('../components/nav.php');
?>

<style>
    .grid {
        display: grid;
        grid-template-columns: 47.5% 5% 47.5%;
        text-align: center;
    }
    
    @media only screen and (max-width: 800px) {
        .grid {
            grid-template-columns: 100%;
        }
        
        .spaceBetween {
            height: 0.4rem;
        }
        
        .containerEditProfile {
            padding: 5px 5px 5px 5px;
        }
    }
</style>

<!-- https://embed.tube/embed-code-generator/twitch/ -->

<body style="background-color: var(--bgColorMain); margin-bottom: 40px">
    <div class="bodyEditProfile">
        <h1 class="pageTitleEditProfile" style="text-decoration: none; font-size: 1.2rem;">Veja Streams em direto:</h1>
        <div class="containerEditProfile grid" style="overflow-x: auto;">
            <div style="padding-bottom: 56.25%; position: relative;"><iframe width="100%" height="100%" src="https://player.twitch.tv/?autoplay=false&channel=blastpremier&parent=valeyesports.farmconnect.pt" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; fullscreen"  style="position: absolute; top: 0px; left: 0px; width: 100%; height: 100%;"><small>Powered by <a href="https://embed.tube/embed-code-generator/twitch/">twitch embed</a> generator</small></iframe></div>
            <div class="spaceBetween" style="position: relative;">&nbsp;</div>      
            <div style="padding-bottom: 56.25%; position: relative;"><iframe width="100%" height="100%" src="https://player.twitch.tv/?autoplay=false&channel=rtparena&parent=valeyesports.farmconnect.pt" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; fullscreen"  style="position: absolute; top: 0px; left: 0px; width: 100%; height: 100%;"><small>Powered by <a href="https://embed.tube/embed-code-generator/twitch/">twitch embed</a> generator</small></iframe></div>
           
           <div class="spaceBetween" style="position: relative;">&nbsp;</div> 
           <div class="spaceBetween" style="position: relative;">&nbsp;</div> 
           <div class="spaceBetween" style="position: relative;">&nbsp;</div> 
           
            <div style="padding-bottom: 56.25%; position: relative;"><iframe width="100%" height="100%" src="https://player.twitch.tv/?autoplay=false&channel=gaules&parent=valeyesports.farmconnect.pt" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; fullscreen"  style="position: absolute; top: 0px; left: 0px; width: 100%; height: 100%;"><small>Powered by <a href="https://embed.tube/embed-code-generator/twitch/">twitch embed</a> generator</small></iframe></div>
            <div class="spaceBetween" style="position: relative;">&nbsp;</div> 
            <div style="padding-bottom: 56.25%; position: relative;"><iframe width="100%" height="100%" src="https://player.twitch.tv/?autoplay=false&channel=esl_csgo&parent=valeyesports.farmconnect.pt" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; fullscreen"  style="position: absolute; top: 0px; left: 0px; width: 100%; height: 100%;"><small>Powered by <a href="https://embed.tube/embed-code-generator/twitch/">twitch embed</a> generator</small></iframe></div>
        </div>
    </div>
    
</body>

<?php 
    include('../components/footer.php');
?>