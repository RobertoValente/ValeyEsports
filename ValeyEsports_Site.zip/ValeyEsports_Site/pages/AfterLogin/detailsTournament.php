<?php
    include('../../scripts/ManageUser/verifyUserNotLog.php');
    $tournamentId = $_GET['torneio'];

    include('../../scripts/Database/connect.php');
    $queryTournamentInfo = "SELECT torneios.idcriador, users.nome as creatorName, torneios.nome as tournamentName, torneios.descricao as descricao, torneios.imagem, torneios.nMaxParticipantes, torneios.dataInicio, torneios.idestado, estadotorneio.estado, torneios.idjogo, jogos.jogo FROM torneios, users, estadotorneio, jogos WHERE torneios.id = ". $tournamentId." and torneios.idcriador = users.id and torneios.idestado = estadotorneio.id and torneios.idjogo = jogos.id";
    $resultTournamentInfo = mysqli_query($ligaBD, $queryTournamentInfo);
    $row = mysqli_fetch_array($resultTournamentInfo);
    $queryNumPlayers = "SELECT idtorneio FROM participantes_torneio where participantes_torneio.idtorneio = ". $tournamentId;
    $resultNumPlayers = mysqli_query($ligaBD, $queryNumPlayers);
    $lenghtNumPlayers = mysqli_num_rows($resultNumPlayers);
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/detailsTournament.css">
    <link rel="stylesheet" href="../../css/global.css">
    <link rel="stylesheet" href="../../css/tournamentTable.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAP - Roberto</title>
</head>

<?php 
    include('../components/nav.php');
?>

<body style="background-color: var(--bgColorMain); margin-bottom: 40px">
    <div class="bodyDetailsTournament">
        <h1 class="pageTitleDetailsTournament">Informações do Torneio:</h1>
        <div class="grid">
            <div class="containerDetailsTournament">
                <h1 style="font-weight: bold; word-break: break-word;"><?php echo $row['tournamentName'] ?> ‎<span style="font-size: 1rem; font-weight: 400;">(<?php echo $row['jogo'] ?>)</span></h1>
                <h4 style="word-break: break-word;"><?php echo $row['descricao'] ?></h4>
                <h5 style="word-break: break-word; margin-top: 2rem;">Participantes: <?php echo $lenghtNumPlayers  ?>/<?php echo $row['nMaxParticipantes'] ?></h5>
                <h5 style="word-break: break-word;">Data de Início: <?php echo $row['dataInicio'] ?></h5>
                <h5 style="word-break: break-word;">Estado: <?php echo $row['estado'] ?></h5>
                <p class="tournamentCreator" style="word-break: break-word; color: #ffffff90; font-size: 1rem;">Criador do Torneio: <?php echo $row['creatorName'] ?></p>

                <?php
                    if($row['idestado'] == 0) {
                        $queryParticipateTournaments = "SELECT idtorneio, iduser FROM participantes_torneio where participantes_torneio.iduser = ". $_SESSION['userId'] ." and participantes_torneio.idtorneio = ". $tournamentId;
                        $resultParticipateTournaments = mysqli_query($ligaBD, $queryParticipateTournaments);
                        $lenghtParticipateTournaments = mysqli_num_rows($resultParticipateTournaments);
                        $userId = $_SESSION['userId'];
                        if($lenghtParticipateTournaments == 0) {
                            if($userId == $row['idcriador']) {
                                echo '<form action="./manageTournament.php" method="POST">';
                                    echo '<div class="tournBtn"><button type="submit" class="primaryBtnDetailsTournament" name="tournament['. $tournamentId .']">Gerir</button></div>';
                                echo '</form>';
                            } else {
                                if($lenghtNumPlayers == $row['nMaxParticipantes']) {
                                    echo "<button class='primaryBtnDetailsTournament' style='cursor: not-allowed'>Cheio</button>";
                                } else {
                                    echo "<a href='../../scripts/ManageTournaments/participateTournament.php?idUser=". $userId ."&idTournament=". $tournamentId ."'><button class='primaryBtnDetailsTournament'>Participar</button></a>";
                                }
                            }
                        } else {
                            echo "<a href='../../scripts/ManageTournaments/removeParticipant.php?idUser=". $userId ."&idTournament=". $tournamentId ."'><button class='primaryBtnDetailsTournament'>Sair</button></a>";
                        }
                    }
                ?>
            </div>
            <div class="imgContainer">
                <img title="Alterar Imagem" style="width: 16rem; height: 16rem; border-radius: 40px;" src="<?php echo $row['imagem']; ?>" alt="Foto do torneio">
            </div>
        </div>

        <?php
            $queryPlayersTree = "SELECT p.idtorneio as torneioId, p.idpartida as partidaId, p.idestado as partidaEstado, p.vencedor as winner, u1.nome as user1, u1.id as userId1, u2.nome as user2, u2.id as userId2 FROM partidas p JOIN users u1 ON u1.id = p.iduser1 JOIN users u2 ON u2.id = p.iduser2 WHERE p.idtorneio = ". $tournamentId;
            // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ Query
            /*
                => Verificar se o vencedor está setado e se não é ele (caso não seja, aplicar o efeito de blur (classe .notDefeated))
            */

            $resultPlayersTree = mysqli_query($ligaBD, $queryPlayersTree);
            $dataPlayersTree = Array();
            while($row2 = mysqli_fetch_array($resultPlayersTree)) {
                array_push($dataPlayersTree, $row2);
            }
        ?>

        <?php if(($row['idestado'] == 1) or ($row['idestado'] == 2)) { ?>
            <?php if($row['nMaxParticipantes'] == 16) { ?>
                <div class="containerDetailsTournament">
                    <div class="tableMax16">
                        <div class="match partida1">
                            <div class="<?php if($dataPlayersTree[0]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[0]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[0]['winner'] == $dataPlayersTree[0]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[0]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[0]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[0]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[0]['winner'] == $dataPlayersTree[0]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[0]['user2']; ?></div>
                        </div>
                        <div></div>
                        <div class="match partida2">
                            <div class="<?php if($dataPlayersTree[1]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[1]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[1]['winner'] == $dataPlayersTree[1]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[1]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[1]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[1]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[1]['winner'] == $dataPlayersTree[1]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[1]['user2']; ?></div>
                        </div>
                        <div></div>
                        <div class="match partida3">
                            <div class="<?php if($dataPlayersTree[2]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[2]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[2]['winner'] == $dataPlayersTree[2]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[2]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[2]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[2]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[2]['winner'] == $dataPlayersTree[2]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[2]['user2']; ?></div>
                        </div>
                        <div></div>
                        <div class="match partida4">
                            <div class="<?php if($dataPlayersTree[3]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[3]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[3]['winner'] == $dataPlayersTree[3]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[3]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[3]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[3]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[3]['winner'] == $dataPlayersTree[3]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[3]['user2']; ?></div>
                        </div>
                        <div></div>
                        <div class="match partida5">
                            <div class="<?php if($dataPlayersTree[4]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[4]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[4]['winner'] == $dataPlayersTree[4]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[4]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[4]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[4]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[4]['winner'] == $dataPlayersTree[4]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[4]['user2']; ?></div>
                        </div>
                        <div></div>
                        <div class="match partida6">
                            <div class="<?php if($dataPlayersTree[5]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[5]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[5]['winner'] == $dataPlayersTree[5]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[5]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[5]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[5]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[5]['winner'] == $dataPlayersTree[5]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[5]['user2']; ?></div>
                        </div>
                        <div></div>
                        <div class="match partida7">
                            <div class="<?php if($dataPlayersTree[6]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[6]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[6]['winner'] == $dataPlayersTree[6]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[6]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[6]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[6]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[6]['winner'] == $dataPlayersTree[6]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[6]['user2']; ?></div>
                        </div>
                        <div></div>
                        <div class="match partida8">
                            <div class="<?php if($dataPlayersTree[7]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[7]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[7]['winner'] == $dataPlayersTree[7]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[7]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[7]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[7]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[7]['winner'] == $dataPlayersTree[7]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[7]['user2']; ?></div>
                        </div>
                    
                        <div style="border-right: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-left: 2px solid black;"></div>
                        <div></div>
                        <div style="border-right: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-left: 2px solid black;"></div>
                        <div></div>
                        <div style="border-right: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-left: 2px solid black;"></div>
                        <div></div>
                        <div style="border-right: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-left: 2px solid black;"></div>

                        <div style="grid-column: 1 / span 2;"></div>
                        <div class="middleLine">‎</div>
                        <div style="grid-column: 4 / span 5;"></div>
                        <div class="middleLine">‎</div>
                        <div style="grid-column: 10 / span 5;"></div>
                        <div class="middleLine">‎</div>
                        <div style="grid-column: 16 / span 5;"></div>
                        <div class="middleLine">‎</div>
                        <div style="grid-column: 22 / span 2;"></div>

                        <div></div>
                        <div class="match partida9">
                            <div class="<?php if($dataPlayersTree[8]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[8]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[8]['winner'] == $dataPlayersTree[8]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[8]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[8]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[8]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[8]['winner'] == $dataPlayersTree[8]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[8]['user2']; ?></div>
                        </div>
                        <div style="grid-column: 5 / span 3;"></div>
                        <div class="match partida10">
                            <div class="<?php if($dataPlayersTree[9]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[9]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[9]['winner'] == $dataPlayersTree[9]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[9]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[9]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[9]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[9]['winner'] == $dataPlayersTree[9]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[9]['user2']; ?></div>
                        </div>
                        <div style="grid-column: 11 / span 3;"></div>
                        <div class="match partida11">
                            <div class="<?php if($dataPlayersTree[10]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[10]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[10]['winner'] == $dataPlayersTree[10]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[10]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[10]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[10]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[10]['winner'] == $dataPlayersTree[10]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[10]['user2']; ?></div>
                        </div>
                        <div style="grid-column: 17 / span 3;"></div>
                        <div class="match partida12">
                            <div class="<?php if($dataPlayersTree[11]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[11]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[11]['winner'] == $dataPlayersTree[11]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[11]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[11]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[11]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[11]['winner'] == $dataPlayersTree[11]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[11]['user2']; ?></div>
                        </div>
                        <div></div>

                        <div style="grid-column: 1 / span 2;"></div>
                        <div class="halfRightLine">‎</div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div class="halfLeftLine">‎</div>
                        <div style="grid-column: 10 / span 5;"></div>
                        <div class="halfRightLine">‎</div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div class="halfLeftLine">‎</div>
                        <div style="grid-column: 22 / span 2;"></div>

                        <div style="grid-column: 1 / span 5;"></div>
                        <div class="middleLine">‎</div>
                        <div style="grid-column: 7 / span 11;"></div>
                        <div class="middleLine">‎</div>
                        <div style="grid-column: 19 / span 5;"></div>

                        <div style="grid-column: 1 / span 4;"></div>
                        <div class="match partida13">
                            <div class="<?php if($dataPlayersTree[12]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[12]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[12]['winner'] == $dataPlayersTree[12]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[12]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[12]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[12]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[12]['winner'] == $dataPlayersTree[12]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[12]['user2']; ?></div>
                        </div>
                        <div style="grid-column: 8 / span 9;"></div>
                        <div class="match partida14">
                            <div class="<?php if($dataPlayersTree[13]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[13]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[13]['winner'] == $dataPlayersTree[13]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[13]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[13]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[13]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[13]['winner'] == $dataPlayersTree[13]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[13]['user2']; ?></div>
                        </div>
                        <div style="grid-column: 20 / span 4;"></div>

                        <div style="grid-column: 1 / span 5;"></div>
                        <div class="halfRightLine">‎</div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;"></div>
                        <div class="halfLeftLine">‎</div>
                        <div style="grid-column: 19 / span 5;"></div>

                        <div style="grid-column: 1 / span 11;"></div>
                        <div class="middleLine">‎</div>
                        <div style="grid-column: 13 / span 11;"></div>

                        <div style="grid-column: 1 / span 9;"></div>
                        <div class="match partidafinal">
                            <div class="<?php if($dataPlayersTree[14]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[14]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[14]['winner'] == $dataPlayersTree[14]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[14]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[14]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[14]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[14]['winner'] == $dataPlayersTree[14]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[14]['user2']; ?></div>
                        </div>
                        <div style="grid-column: 15 / span 9;"></div>
                    </div>
                </div>
            <?php } ?>

            <?php if($row['nMaxParticipantes'] == 8) { ?>
                <div class="containerDetailsTournament">
                    <div class="tableMax8">
                        <div class="match partida1">
                            <div class="<?php if($dataPlayersTree[0]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[0]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[0]['winner'] == $dataPlayersTree[0]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[0]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[0]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[0]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[0]['winner'] == $dataPlayersTree[0]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[0]['user2']; ?></div>
                        </div>
                        <div></div>
                        <div class="match partida2">
                            <div class="<?php if($dataPlayersTree[1]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[1]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[1]['winner'] == $dataPlayersTree[1]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[1]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[1]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[1]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[1]['winner'] == $dataPlayersTree[1]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[1]['user2']; ?></div>
                        </div>
                        <div></div>
                        <div class="match partida3">
                            <div class="<?php if($dataPlayersTree[2]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[2]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[2]['winner'] == $dataPlayersTree[2]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[2]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[2]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[2]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[2]['winner'] == $dataPlayersTree[2]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[2]['user2']; ?></div>
                        </div>
                        <div></div>
                        <div class="match partida4">
                            <div class="<?php if($dataPlayersTree[3]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[3]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[3]['winner'] == $dataPlayersTree[3]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[3]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[3]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[3]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[3]['winner'] == $dataPlayersTree[3]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[3]['user2']; ?></div>
                        </div>

                        <div style="border-right: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-left: 2px solid black;"></div>
                        <div></div>
                        <div style="border-right: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-left: 2px solid black;"></div>

                        <div style="grid-column: 1 / span 2;">‎</div>
                        <div class="middleLine">‎</div>
                        <div style="grid-column: 4 / span 5;">‎</div>
                        <div class="middleLine">‎</div>
                        <div style="grid-column: 10 / span 2;">‎</div>
                        
                        <div></div>
                        <div class="match partida5">
                            <div class="<?php if($dataPlayersTree[4]['partidaEstado'] == 0) {echo "notStarted";} ?>  <?php if($dataPlayersTree[4]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[4]['winner'] == $dataPlayersTree[4]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[4]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[4]['partidaEstado'] == 0) {echo "notStarted";} ?>  <?php if($dataPlayersTree[4]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[4]['winner'] == $dataPlayersTree[4]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[4]['user2']; ?></div>
                        </div>
                        <div style="grid-column: 5 / span 3;">‎</div>
                        <div class="match partida6">
                            <div class="<?php if($dataPlayersTree[5]['partidaEstado'] == 0) {echo "notStarted";} ?>  <?php if($dataPlayersTree[5]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[5]['winner'] == $dataPlayersTree[5]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[5]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[5]['partidaEstado'] == 0) {echo "notStarted";} ?>  <?php if($dataPlayersTree[5]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[5]['winner'] == $dataPlayersTree[5]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[5]['user2']; ?></div>
                        </div>
                        <div></div>

                        <div></div>
                        <div></div>
                        <div class="halfRightLine"></div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div style="border-bottom: 2px solid black;">‎</div>
                        <div class="halfLeftLine"></div>
                        <div></div>
                        <div></div>

                        <div style="grid-column: 1 / span 5;">‎</div>
                        <div class="middleLine">‎</div>
                        <div style="grid-column: 7 / span 5;">‎</div>

                        <div style="grid-column: 1 / span 3;">‎</div>
                        <div class="match partidaFinal">
                            <div class="<?php if($dataPlayersTree[6]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[6]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[6]['winner'] == $dataPlayersTree[6]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[6]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[6]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[6]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[6]['winner'] == $dataPlayersTree[6]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[6]['user2']; ?></div>
                        </div>
                        <div style="grid-column: 9 / span 3;">‎</div>
                    </div>
                </div>
            <?php } ?>

            <?php if($row['nMaxParticipantes'] == 4) { ?>
                <div class="containerDetailsTournament">
                    <div class="tableMax4">
                        <div class="match partida1">
                            <div class="<?php if($dataPlayersTree[0]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[0]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[0]['winner'] == $dataPlayersTree[0]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[0]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[0]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[0]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[0]['winner'] == $dataPlayersTree[0]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[0]['user2']; ?></div>
                        </div>
                        <div></div>
                        <div class="match partida2">
                            <div class="<?php if($dataPlayersTree[1]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[1]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[1]['winner'] == $dataPlayersTree[1]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[1]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[1]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[1]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[1]['winner'] == $dataPlayersTree[1]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[1]['user2']; ?></div>
                        </div>

                        <div style="border-right: 2px solid black;"></div>
                        <div style="border-bottom: 2px solid black">‎</div>
                        <div style="border-bottom: 2px solid black">‎</div>
                        <div style="border-bottom: 2px solid black">‎</div>
                        <div style="border-left: 2px solid black;"></div>

                        <div style="grid-column: 1 / span 2;">‎</div>
                        <div class="middleLine">‎</div>
                        <div style="grid-column: 4 / span 2;">‎</div>

                        <div></div>
                        <div class="match partidaFinal">
                            <div class="<?php if($dataPlayersTree[2]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[2]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[2]['winner'] == $dataPlayersTree[2]['userId1']) {echo 'notDefeated';}} ?>" class="player1"><?php echo $dataPlayersTree[2]['user1']; ?></div>
                            <div class="vsLabel">vs</div>
                            <div class="<?php if($dataPlayersTree[2]['partidaEstado'] == 0) {echo "notStarted";} ?> <?php if($dataPlayersTree[2]['partidaEstado'] == 1) {echo "";} else {if($dataPlayersTree[2]['winner'] == $dataPlayersTree[2]['userId2']) {echo 'notDefeated';}} ?>" class="player2"><?php echo $dataPlayersTree[2]['user2']; ?></div>
                        </div>
                        <div></div>
                    </div>
                </div>
            <?php } ?>
        <?php } ?>
    </div>
    
</body>

<?php 
    include('../components/footer.php');
?>