<?php
    include('../../scripts/ManageUser/verifyUserNotLog.php');
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/createTournament.css">
    <link rel="stylesheet" href="../../css/global.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.7.2.min.js"></script>
    <title>PAP - Roberto</title>
</head>

<?php 
    include('../components/nav.php');
?>

<body style="background-color: var(--bgColorMain); margin-bottom: 40px">
    <div class="bodyCreateTournament">
        <h1 class="pageTitleCreateTournament">Criar Torneio:</h1>
        <div class="containerCreateTournament">
            <form action="../../scripts/ManageTournaments/createTournament.php" method="POST" enctype="multipart/form-data">
                <label>Nome:</label> <br>
                <input class="inputCustom" name="nome" type="text" value="" required>
                <br> <br>
                <label>Descrição:</label> <br>
                <textarea name="descricao" cols="25" rows="5" class="inputCustom" required></textarea>
                <br> <br>
                <label>Dia/Hora de Início:</label> <br>
                <input class="inputCustom" id="inputData" name="data" type="datetime-local" placeholder="Dia e Hora" required>
                <br> <br>
                <label>Número máximo de participantes:</label> <br>
                <select name="nMaxParticipantes" id="jogos" class="inputCustom" required>
                    <option value="" disabled selected hidden>Escolha o número de participantes...</option>
                    <option value="4">4 participantes</option>
                    <option value="8">8 participantes</option>
                    <option value="16">16 participantes</option>
                    <!--<option value="32">32 participantes</option>
                    <option value="64">64 participantes</option>-->
                </select>
                <br> <br>
                <label>Jogo:</label> <br>
                <select name="jogos" id="jogos" class="inputCustom" required>
                    <option value="" disabled selected hidden>Escolha um jogo...</option>
                    <?php
                        include('../../scripts/Database/connect.php');
                        $queryGames = "SELECT id, jogo FROM jogos";
                        $resultGames = mysqli_query($ligaBD, $queryGames);
                        while($row = mysqli_fetch_array($resultGames)) {
                            echo "<option value='". $row['id'] ."'>". $row['jogo'] ."</option>";
                        }
                    ?>
                </select>
                <br> <br>
                <label>Imagem do Torneio:</label> <br>
                <input class="inputCustom" name="image" type="file" accept=".png, .jpg, .jpeg"  placeholder="Abrir files para selecionar o ficheiro" required>
                <br>
                <br>
                <input class="primaryBtnCreateTournament" type="submit" value="Criar Torneio" />
            </form>          
        </div>
    </div>
    
</body>

<script type="text/javascript">
    const dateControl = document.querySelector('input[type="datetime-local"]');
    const now = new Date();
    const year = now.getFullYear();
    const month = (now.getMonth() + 1).toString().padStart(2, '0');
    const day = now.getDate().toString().padStart(2, '0');
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    dateControl.min = `${year}-${month}-${day}T${hours}:${minutes}`;
</script>

<?php 
    include('../components/footer.php');
?>