<?php
    include('../../scripts/ManageUser/verifyUserNotLog.php');
    include('../../scripts/ManageUser/verifyAdmNotLog.php');
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/adminPanel.css">
    <link rel="stylesheet" href="../../css/global.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAP - Roberto</title>
</head>

<?php 
    include('../components/nav.php');
?>

<body style="background-color: var(--bgColorMain); margin-bottom: 40px">
    <div class="bodyAdminPanel">
        <h1 class="pageTitleAdminPanel">Painel de Administração:</h1>
        <div class="containerAdminPanel">
            <div class="gridAdminPanel">
                <!-- LINHA 1 -->
                <div class="gridItemAdminPanel">
                    <a href="../InsideAdminPanel/aproveUsers.php" style="text-decoration: none;">
                        <button disabled class="btnPanelAdminPanel">Aprovar Utilizadores</button>
                    </a>
                </div>
                <div class="gridItemAdminPanel">
                    <a href="../InsideAdminPanel/manageUsers.php" style="text-decoration: none;">
                        <button class="btnPanelAdminPanel">Gerir Utilizadores</button>
                    </a>
                </div>
                <div class="gridItemAdminPanel">
                    <a href="../InsideAdminPanel/manageUserEstados.php" style="text-decoration: none;">
                        <button disabled class="btnPanelAdminPanel">Gerir Estados de Utilizadores</button>
                    </a>
                </div>

                <!-- LINHA 2 -->
                <div class="gridItemAdminPanel">
                    <a href="../InsideAdminPanel/manageTournaments.php" style="text-decoration: none;">
                        <button class="btnPanelAdminPanel">Gerir Torneios</button>
                    </a>
                </div>
                <div class="gridItemAdminPanel">
                    <a href="../InsideAdminPanel/manageRounds.php" style="text-decoration: none;">
                        <button class="btnPanelAdminPanel">Gerir Partidas</button>
                    </a>
                </div>
                <div class="gridItemAdminPanel">
                    <a href="../InsideAdminPanel/manageParticipants.php" style="text-decoration: none;">
                        <button class="btnPanelAdminPanel">Gerir Participantes</button>
                    </a>
                </div>

                <!-- LINHA 3 -->
                <div class="gridItemAdminPanel">
                    <a href="../InsideAdminPanel/manageGames.php" style="text-decoration: none;">
                        <button class="btnPanelAdminPanel">Gerir Jogos</button>
                    </a>
                </div>
                <div class="gridItemAdminPanel">
                    <a href="../InsideAdminPanel/viewLogs.php" style="text-decoration: none;">
                        <button class="btnPanelAdminPanel">Ver Logs</button>
                    </a>
                </div>
                <div class="gridItemAdminPanel">
                    <a href="#" style="text-decoration: none;">
                        <button disabled class="btnPanelAdminPanel">. . .</button>
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>

<?php 
    include('../components/footer.php');
?>