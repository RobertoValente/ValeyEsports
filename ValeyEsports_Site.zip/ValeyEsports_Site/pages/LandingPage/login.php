<?php
    include('../../scripts/ManageUser/verifyUserLog.php');
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/loginPage.css">
    <link rel="stylesheet" href="../../css/global.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAP - Roberto</title>
</head>

<nav class="navbar navbar-expand-sm navbar-light">
    <div class="container-fluid">
        <a href="index.php" class="navbar-brand text-white">
            <img src="../../images/logo.png" height="36" alt="CoolBrand">
        </a>
        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="white" class="bi bi-list" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
            </svg>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto">
                <a href="index.php" class="nav-item nav-link">
                    <button type="button" class="btn btn-outline-light">Voltar</button>
                </a>
            </div>
        </div>
    </div>
</nav>

<body style="background-color: var(--bgColorMain); margin-bottom: 40px">
    <div class="bodyLoginPage">
        <h1 class="pageTitleLoginPage">Login</h1>
        <div class="containerLoginPage">
            <?php
                if(isset($_SESSION['nao_autenticado'])) {
                    echo '<div class="divAlertLoginPage">';
                        echo 'Email ou Password inválidos.';
                    echo '</div>';
                    unset($_SESSION['nao_autenticado']);
                }

                if(isset($_SESSION['nao_aprovado'])) {
                    echo '<div class="divAlertLoginPage">';
                        echo 'Aguarde até ser Aprovado.';
                    echo '</div>';
                    unset($_SESSION['nao_aprovado']);
                }

                if(isset($_SESSION['banido'])) {
                    echo '<div class="divAlertLoginPage">';
                        echo 'Esta conta foi Banida.';
                    echo '</div>';
                    unset($_SESSION['banido']);
                }

                if(isset($_SESSION['eliminado'])) {
                    echo '<div class="divAlertLoginPage">';
                        echo 'Esta conta foi Eliminada.';
                    echo '</div>';
                    unset($_SESSION['eliminado']);
                }

                if(isset($_SESSION['conta_criada'])) {
                    echo '<div class="divSuccessLoginPage">';
                        echo 'A sua conta foi criada, pode fazer Login.';
                    echo '</div>';
                    unset($_SESSION['conta_criada']);
                }

                if(isset($_SESSION['newPasswordSetted'])) {
                    echo '<div class="divSuccessLoginPage">';
                        echo 'Password Alterada com Sucesso.';
                    echo '</div>';
                    unset($_SESSION['newPasswordSetted']);
                }
            ?>
            <div class="box">
                <form action="../../scripts/ManageUser/login.php" method="POST">
                    <br>
                    <label for="lblEmail" class="lblEmailLoginPage">Email: </label>
                    <input type="text" name="email" class="inputEmailLoginPage" autofocus="" required> <br>
                    <label for="lblPass" class="lblPassLoginPage">Password: </label>
                    <input type="password" name="password" class="inputPassLoginPage" required> <br>
                    <button type="submit" class="btnLoginPage">Login</button>
                </form>
                <a href="registar.php" style="text-decorations: none;">
                    <button class="btnLoginPage">Criar Conta</button>
                </a>
                <br> <br>
            </div>
        </div>
    </div>
</body>

<?php 
    include('../components/footer.php');
?>