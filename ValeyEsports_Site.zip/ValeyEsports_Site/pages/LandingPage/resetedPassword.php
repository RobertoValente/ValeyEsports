<?php
    include('../../scripts/ManageUser/verifyUserLog.php');
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/resetedPasswordPage.css">
    <link rel="stylesheet" href="../../css/global.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAP - Roberto</title>
</head>

<nav class="navbar navbar-expand-sm navbar-light">
    <div class="container-fluid">
        <a href="index.php" class="navbar-brand text-white">
            <img src="../../images/logo.png" height="36" alt="CoolBrand">
        </a>
        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="white" class="bi bi-list" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
            </svg>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto">
                <a href="index.php" class="nav-item nav-link">
                    <button type="button" class="btn btn-outline-light">Voltar</button>
                </a>
            </div>
        </div>
    </div>
</nav>

<body style="background-color: var(--bgColorMain); margin-bottom: 40px">
    <div class="bodyResetedPasswordPage">
        <h1 class="pageTitleResetedPasswordPage">Defina uma Nova Password</h1>
        <div class="containerResetedPasswordPage">
            <div class="divAlertResetedPasswordPage">
                <?php
                    if(isset($_SESSION['emailOldPass_errado'])) {
                        echo "Email ou Antiga Password está inválido.";
                        unset($_SESSION['emailOldPass_errado']);
                    } else if(isset($_SESSION['differentPassword'])) {
                        echo "As passwords não são iguais.";
                        unset($_SESSION['differentPassword']);
                    } else {
                        echo "A sua password foi resetada por um Administrador.";
                    }
                    
                    if(isset($_SESSION['differentPassword'])) {
                        echo "As passwords não são iguais.";
                        unset($_SESSION['differentPassword']);
                    }
                ?>
                
            </div>
            <div class="box">
                <form action="../../scripts/ManageUser/userSetNewPassword.php" method="POST">
                    <br>
                    <label for="lblEmail" class="lblEmailResetedPasswordPage">Email: </label>
                    <input type="text" name="email" class="inputEmailResetedPasswordPage" autofocus="" required> <br>
                    <label for="lblOldPass" class="lblOldPassResetedPasswordPage">Antiga Password: </label>
                    <input type="password" name="oldPassword" class="inputOldPassResetedPasswordPage" required> <br>
                    <label for="lblNewPass" class="lblNewPassResetedPasswordPage">Nova Password: </label>
                    <input type="password" name="password" class="inputNewPassResetedPasswordPage" required> <br>
                    <label for="lblNewPassConfirm" class="lblNewPassConfirmResetedPasswordPage">Confirme a Nova Password: </label>
                    <input type="password" name="passwordConfirm" class="inputNewPassConfirmResetedPasswordPage" required> <br>
                    <button type="submit" class="btnResetedPasswordPage">Guardar</button>
                </form>
            </div>
        </div>
    </div>
</body>

<?php 
    include('../components/footer.php');
?>