<!DOCTYPE html>
<html lang="en">

<?php
    include('../../scripts/ManageUser/verifyUserLog.php');
    include('../../scripts/Database/connect.php');
    $queryStatistics = "select (select count(users.id) as nUsers FROM users) nUsers, (select count(jogos.id) as nJogos from jogos) nJogos, (select count(torneios.id) as nTorneios from torneios where torneios.idestado = 0) nTorneios from dual";
    $resultStatistics = mysqli_query($ligaBD, $queryStatistics);
    $row = mysqli_fetch_array($resultStatistics);
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/global.css">
    <link rel="stylesheet" href="../../css/landingpage.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAP - Roberto</title>
</head>

<body>
    <!-- ====================== NAV ====================== -->
    <nav class="navbar navbar-expand-sm navbar-light sticky-top">
        <div class="container-fluid">
            <a href="#" class="navbar-brand text-white">
                <img src="../../images/logo.png" height="36" alt="CoolBrand">
            </a>
            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="white" class="bi bi-list" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
                </svg>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto">
                    <a href="#sobre" class="navItem">Sobre</a>
                    <a href="#trabalho" class="navItem">Nosso Trabalho</a>
                    <a href="#faq" class="navItem">FAQ</a>
                </div>
                <div class="navbar-nav ms-auto">
                    <a href="login.php" class="nav-item nav-link">
                        <button type="button" class="btn btn-outline-light">Entrar</button>
                    </a>
                </div>
            </div>
        </div>
    </nav>
    <!-- ================================================= -->
    
    <main>
        <!-- ====================== STATUS =================== -->
        <div class="statusDiv">
            <div class="insideStatus">
                <h1 class="insideStatusH1">A tua Plataforma de eSports Preferida!</h1>
                <p class="insideStatusP">Aqui podes escolher entre competir com milhares de pessoas ou gerir competições.</p>
                
                <div class="grid-containerStatus">
                    <div class="grid-itemStatus">
                        <img src="../../images/society.png" width="80" height="80" alt="Ícone de Grupo de Pessoas">
                        <br>
                        <?php echo $row['nUsers']; ?>
                        <br> 
                        Utilizadores Registrados
                    </div>
                    <div class="grid-itemStatus">
                        <img src="../../images/monitor.png" width="80" height="80" alt="Ícone de Monitor de Computador">
                        <br>
                        <?php echo $row['nJogos']; ?> 
                        <br> 
                        Jogos Registrados
                    </div>
                    <div class="grid-itemStatus">
                        <img src="../../images/trophy.png" width="80" height="80" alt="Ícone de Troféu">
                        <br>
                        <?php echo $row['nTorneios']; ?> 
                        <br> 
                        Torneios Disponíveis
                    </div>
                </div>

                <div style="text-align: center;">
                    <a href="login.php">
                        <button type="button" class="insideStatusBtn">Comece Agora</button>
                    </a>
                    <br>
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="white" class="bi bi-chevron-double-down" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M1.646 6.646a.5.5 0 0 1 .708 0L8 12.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                        <path fill-rule="evenodd" d="M1.646 2.646a.5.5 0 0 1 .708 0L8 8.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
                    </svg>
                </div>
            </div>
        </div>
        <!-- ================================================= -->

        <!-- ====================== SOBRE ==================== -->
        <div id="sobre" class="sobreDiv">
            <div class="insideSobre">s
                <h1 class="insideSobreH1">Sobre</h1>
                <div class="grid-containerSobre">
                    <div class="imgSobre" style="text-align: center; vertical-align: middle;">
                        <img src="../../images/logo.png" width="300" height="300" alt="Logotipo Valey">
                    </div>
                    <div class="grid-itemSobre">
                        <div class="txtSobre">
                            <h3 style="text-align: center; font-weight: bold;">"Gamers never die, they Respawn!"</h3>
                            <p>A ideia do Projeto ValeyEsports é ser uma plataforma para Criação, Gestão e Participação em Torneios de eSports. Juntamente com a plataforma também será desenvolvido uma solução integrada para controlo de acessos em Eventos Presenciais. As principais coisas que irão ser desenvolvidas neste projeto serão:</p>
                            <ul>
                                <li>Aplicação Mobile;</li>
                                <li>Website;</li>
                                <li>Sistema RFID.</li>
                            </ul>
                            <p>Para mais informações, <a href="https://robertovalente1.wixsite.com/blogpap" target="_blank">acompanhe o Blog</a>.</p>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ================================================= -->

        <!-- ================= NOSSO TRABALHO ================ -->
        <div id="trabalho" class="sobreDiv">
            <div class="insideSobre" style="background-color: var(--bgColorMain);">
                <h1 class="insideSobreH1">Nosso Trabalho</h1>
                <div class="grid-containerSobre">
                    <div class="imgSobre" style="text-align: center; vertical-align: middle;">
                        <img style="margin-top: 24px" src="../../images/administrate.png" width="264" height="264" alt="Logotipo Valey">
                    </div>
                    <div class="grid-itemSobre">
                        <div class="txtSobre">
                            <p>Descubra uma plataforma revolucionária que facilita a criação, gestão e participação. Com a nossa plataforma intuitiva, você pode criar torneios e gerenciar tudo em um só lugar. Além disso, participe de comunidades envolventes e faça conexões significativas. A nossa plataforma oferece uma experiência simplificada para utilizadores de todas as áreas. Junte-se a nós e aproveite a facilidade de criar, gerenciar e de participar em torneios.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ================================================= -->

        <div id="faq" class="faqDiv">
            <div class="insideFaq">
                <h1 class="insideFaqH1">F.A.Q.</h1>
                <div class="accordion  testFaq" id="accordionExample">
                    <?php
                        header('Content-Type: text/html; charset=utf-8');
                        $queryFaq = "SELECT id, pergFaq, resFaq FROM faqinfo";
                        $resultFaq = mysqli_query($ligaBD, $queryFaq);
                        $lenghtFaq = mysqli_num_rows($resultFaq);
                        if($lenghtFaq == 0) {
                            echo "Não foram encontrados resultados!";
                        } else {
                            while($row = mysqli_fetch_array($resultFaq)) {
                                echo '<div class="accordion-item">';
                                    echo '<h2 class="accordion-header" id="heading'. $row['id'] .'">';
                                        echo '<button style="font-weight: bold;" class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse'. $row['id'] .'" aria-expanded="false" aria-controls="collapse'. $row['id'] .'">';
                                            echo $row['pergFaq'];
                                        echo '</button>';
                                    echo '</h2>';
                                    echo '<div id="collapse'. $row['id'] .'" class="accordion-collapse collapse" aria-labelledby="heading'. $row['id'] .'" data-bs-parent="#accordionExample">';
                                        echo '<div class="accordion-body">';
                                            echo '<p>'. $row['resFaq'] .'</p>';
                                        echo '</div>';
                                    echo '</div>';
                                echo '</div>';
                            }
                        }
                    ?>
                </div>
            </div>
        </div>
    </main>

    <!-- ===================== FOOTER ==================== -->
    <footer>
        Este projeto é uma ideia para a PAP do curso Gestão e Programação de Sistemas Informáticos.
        <br>
        Feito por <a href="https://github.com/RobertoValente" target="_blank" style="color: white;">Roberto Valente</a>
    </footer>
    <!-- ================================================= -->
</body>
</html>