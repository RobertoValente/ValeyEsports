<?php
    include('../../scripts/Database/connect.php');
    include('../../scripts/ManageUser/verifyUserNotLog.php');
    include('../../scripts/ManageUser/verifyAdmNotLog.php');
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/manageTournaments.css">
    <link rel="stylesheet" href="../../css/global.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAP - Roberto</title>

    <link href='../../Extras/DataTables/datatables.min.css' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="../../Extras/jquery-3.5.1.min.js"></script>
    <script type="text/javascript" src="../../Extras/DataTables/datatables.min.js"></script>
</head>

<?php 
    include('../components/nav.php');
?>

<body style="background-color: var(--bgColorMain); margin-bottom: 40px">
    <div class="bodyManageTournaments">
        <h1 class="pageTitleManageTournaments">Gestão de Torneios:</h1>
        <div class="containerManageTournaments">
            <table class="ManageTournamentsTable" class="display dataTable">
                <thead>
                    <tr>
                        <th style="text-align: center;">Nome do Torneio</th>
                        <th style="text-align: center;">Nome do Criador</th>
                        <th style="text-align: center;">Participantes</th>
                        <th style="text-align: center;">Data de Ínicio</th>
                        <th style="text-align: center;">Jogo</th>
                        <th style="text-align: center;">Estado</th>
                        <th style="text-align: center;">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $result = mysqli_query($ligaBD, "SELECT torneios.id, users.nome as nomeCriador, torneios.nome as nomeTorneio, torneios.nMaxParticipantes,  torneios.dataInicio, torneios.idestado, estadotorneio.estado, jogos.jogo FROM  torneios, users, estadotorneio, jogos WHERE torneios.idcriador = users.id and torneios.idestado = estadotorneio.id and torneios.idjogo = jogos.id and torneios.idestado <> 3");
                        $row1Length = mysqli_num_rows($result);
                        while($row = mysqli_fetch_array($result)) {
                            $queryGetPlayers = "SELECT count(participantes_torneio.iduser) as number FROM participantes_torneio WHERE participantes_torneio.idtorneio = ". $row['id'];
                            $resultGetPlayers = mysqli_query($ligaBD, $queryGetPlayers);
                            $row2 = mysqli_fetch_array($resultGetPlayers);
                            echo "<tr>";
                                echo "<td style='text-align: center;'>". $row['nomeTorneio'] ."</td>";
                                echo "<td style='text-align: center;'>". $row['nomeCriador'] ."</td>";
                                echo "<td style='text-align: center;'>". $row2['number'] ."/". $row['nMaxParticipantes'] ."</td>";
                                echo "<td style='text-align: center;'>". $row['dataInicio'] ."</td>";
                                echo "<td style='text-align: center;'>". $row['estado'] ."</td>";
                                echo "<td style='text-align: center;'>". $row['jogo'] ."</td>";
                                echo "<td style='text-align: center;'>";
                                    if($row['idestado'] == 0) {
                                        echo "<a onclick='return confirm(`Tem certeza que deseja iniciar este torneio?`);' href='../../scripts/StartTournament/begin.php?idTorneio=". $row['id'] ."'><img heiht=22 width=22 alt='Inicar torneio' title='Iniciar' src='../../images/start.png'></a>";
                                        echo "   ";
                                    }

                                    if(($row['idestado'] == 0) or ($row['idestado'] == 1)) {
                                        echo "<a style='cursor: not-allowed;' pointer ><img heiht=22 width=22 alt='Editar torneio' title='Editar' src='../../images/edit.png'></a>";
                                        //echo "<a onclick='return confirm(`Tem certeza que deseja editar este torneio?`);' href='../../scripts/ManageTournaments/#.php?idTorneio=". $row['id'] ."'><img heiht=22 width=22 alt='Editar torneio' title='Editar' src='../../images/edit.png'></a>";
                                        echo "   ";
                                    }
                                    echo "<a onclick='return confirm(`Tem certeza que deseja eliminar este torneio?`);' href='../../scripts/ManageTournaments/setEliminated.php?idTorneio=". $row['id'] ."'><img heiht=22 width=22 alt='Eliminar torneio' title='Eliminar' src='../../images/delete.png'></a>";
                                echo "</td>";
                            echo "</tr>";
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

<script>
    $(document).ready(function(){
        $('.ManageTournamentsTable').DataTable({
            rowReorder: {
                selector: 'td:nth-child(4)'
            },
            responsive: true,
            "language": {
                "processing":   "A processar...",
                "lengthMenu":   "Mostrar _MENU_ registos",
                "zeroRecords":  "Não foram encontrados resultados",
                "info":         "Mostrando de _START_ até _END_ de _TOTAL_ registos",
                "infoEmpty":    "Mostrando de 0 até 0 de 0 registos",
                "infoFiltered": "(filtrado de _MAX_ registos no total)",
                "infoPostFix":  "",
                "search":       "Procurar:",
                "url":          "",
                "paginate": {
                    "first":    "Primeiro",
                    "previous": "Anterior",
                    "next":     "Seguinte",
                    "last":     "Último"
                }
            }
        });
    });
</script>

<?php 
    include('../components/footer.php');
?>