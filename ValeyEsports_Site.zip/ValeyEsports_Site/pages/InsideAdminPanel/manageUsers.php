<?php
    include('../../scripts/Database/connect.php');
    include('../../scripts/ManageUser/verifyUserNotLog.php');
    include('../../scripts/ManageUser/verifyAdmNotLog.php');
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/manageUsers.css">
    <link rel="stylesheet" href="../../css/global.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAP - Roberto</title>

    <link href='../../Extras/DataTables/datatables.min.css' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="../../Extras/jquery-3.5.1.min.js"></script>
    <script type="text/javascript" src="../../Extras/DataTables/datatables.min.js"></script>
</head>

<?php 
    include('../components/nav.php');
?>

<body style="background-color: var(--bgColorMain); margin-bottom: 40px">
    <div class="bodyManageUsers">
        <h1 class="pageTitleManageUsers">Gestão de Utilizadores:</h1>
        <div class="containerManageUsers">
            <table class="ManageUsersTable" class="display dataTable">
                <thead>
                    <tr>
                        <th style="text-align: center;">Nome</th>
                        <th style="text-align: center;">Email</th>
                        <th style="text-align: center;">Password</th>
                        <th style="text-align: center;">Tipo</th>
                        <th style="text-align: center;">Estado</th>
                        <th style="text-align: center;">Data de Criação</th>
                        <th style="text-align: center;">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $result = mysqli_query($ligaBD, "SELECT users.id, users.nome, users.email, users.password, tipouser.tipo as tipo, estadouser.estado as estado, users.createdAt, users.idestado FROM users, tipouser, estadouser WHERE (NOT users.idestado = 0) and (users.idtipo = tipouser.id) and (users.idestado = estadouser.id)");
                        $row1Length = mysqli_num_rows($result);
                        $password = "Resetar";
                        while($row = mysqli_fetch_array($result)) {
                            if(($row['id'] !== "0") and ($row['id'] !== "1")) {
                                echo "<tr>";
                                    echo "<td style='text-align: center;'>". $row['nome'] ."</td>";
                                    echo "<td style='text-align: center;'>". $row['email'] ."</td>";
                                    if (preg_match("/changed0000000000/", $row['password'])) {
                                        echo "<td style='text-align: center;'>Está Resetada</td>";
                                    } else {
                                        echo "<td style='text-align: center;'> <a onclick='return confirm(`Tem certeza que deseja resetar a password deste utilizador?`);' href='../../scripts/ManageUser/userSetResetPassword.php?idUser=". $row['id'] ."'><img heiht=22 width=22 alt='Resetar password' title='Resetar' src='../../images/resetpw.png'></a></td>";
                                    }
                                    echo "<td style='text-align: center;'>". $row['tipo'] ."</td>";
                                    echo "<td style='text-align: center;'>". $row['estado'] ."</td>";
                                    echo "<td style='text-align: center;'>". $row['createdAt'] ."</td>";
                                    echo "<td style='text-align: center;'>";
                                        echo "<a href='./editUser.php?idUser=". $row['id'] ."'><img heiht=22 width=22 alt='Editar utilizador' title='Editar' src='../../images/edit.png'></a>";
                                        if($row['id'] != $_SESSION['userId']) {
                                            echo "   ";
                                            echo "<a onclick='return confirm(`Tem certeza que deseja eliminar este utilizador?`);' href='../../scripts/ManageUser/userSetEliminated.php?idUser=". $row['id'] ."'><img heiht=22 width=22 alt='Eliminar utilizador' title='Eliminar' src='../../images/delete.png'></a>";
                                            echo "   ";
                                            echo "<a onclick='return confirm(`Tem certeza que deseja banir este utilizador?`);' href='../../scripts/ManageUser/userSetBanned.php?idUser=". $row['id'] ."'><img heiht=22 width=22 alt='Banir utilizador' title='Banir' src='../../images/block.png'></a>";
                                        }
                                    echo "</td>";
                                echo "</tr>";
                            }
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

<script>
    $(document).ready(function(){
        $('.ManageUsersTable').DataTable({
            rowReorder: {
                selector: 'td:nth-child(4)'
            },
            responsive: true,
            "language": {
                "processing":   "A processar...",
                "lengthMenu":   "Mostrar _MENU_ registos",
                "zeroRecords":  "Não foram encontrados resultados",
                "info":         "Mostrando de _START_ até _END_ de _TOTAL_ registos",
                "infoEmpty":    "Mostrando de 0 até 0 de 0 registos",
                "infoFiltered": "(filtrado de _MAX_ registos no total)",
                "infoPostFix":  "",
                "search":       "Procurar:",
                "url":          "",
                "paginate": {
                    "first":    "Primeiro",
                    "previous": "Anterior",
                    "next":     "Seguinte",
                    "last":     "Último"
                }
            }
        });
    });
</script>

<?php 
    include('../components/footer.php');
?>