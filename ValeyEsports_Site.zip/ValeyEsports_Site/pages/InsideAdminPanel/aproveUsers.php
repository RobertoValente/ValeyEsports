<?php
    include('../../scripts/Database/connect.php');
    include('../../scripts/ManageUser/verifyUserNotLog.php');
    include('../../scripts/ManageUser/verifyAdmNotLog.php');
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/aproveUsers.css">
    <link rel="stylesheet" href="../../css/global.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAP - Roberto</title>

    <link href='../../Extras/DataTables/datatables.min.css' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="../../Extras/jquery-3.5.1.min.js"></script>
    <script type="text/javascript" src="../../Extras/DataTables/datatables.min.js"></script>
</head>

<?php 
    include('../components/nav.php');
?>

<body style="background-color: var(--bgColorMain); margin-bottom: 40px">
    <div class="bodyAproveUsers">
        <h1 class="pageTitleAproveUsers">Aprovação de Utilizadores:</h1>
        <div class="containerAproveUsers">
            <table class="aproveUsersTable" class="display dataTable">
                <thead>
                    <tr>
                        <th style="text-align: center;">Id</th>
                        <th style="text-align: center;">Nome</th>
                        <th style="text-align: center;">Email</th>
                        <th style="text-align: center;">Data de Criação</th>
                        <th style="text-align: center;">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $result = mysqli_query($ligaBD, "SELECT * FROM users WHERE users.idestado = 0");
                        $row1Length = mysqli_num_rows($result);
                        while($row = mysqli_fetch_array($result)) {
                            echo "<tr>";
                                echo "<td style='text-align: center;'>". $row['id'] ."</td>";
                                echo "<td style='text-align: center;'>". $row['nome'] ."</td>";
                                echo "<td style='text-align: center;'>". $row['email'] ."</td>";
                                echo "<td style='text-align: center;'>". $row['createdAt'] ."</td>";
                                echo "<td style='text-align: center;'>";
                                    echo "<a onclick='return confirm(`Tem certeza que deseja aprovar este utilizador?`);' href='../../scripts/ManageUser/userSetApproved.php?idUser=". $row['id'] ."'><img heiht=22 width=22 alt='Aprovar utilizador' title='Aprovar' src='../../images/accept.png'></a>";
                                    echo "     ";
                                    echo "<a onclick='return confirm(`Tem certeza que deseja recusar este utilizador?`);' href='../../scripts/ManageUser/userSetNotApproved.php?idUser=". $row['id'] ."'><img heiht=22 width=22 alt='Recusar utilizador' title='Recusar' src='../../images/cancel.png'></a>";
                                echo "</td>";
                            echo "</tr>";
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

<script>
    $(document).ready(function(){
        $('.aproveUsersTable').DataTable({
            rowReorder: {
                selector: 'td:nth-child(4)'
            },
            responsive: true,
            "language": {
                "processing":   "A processar...",
                "lengthMenu":   "Mostrar _MENU_ registos",
                "zeroRecords":  "Não foram encontrados resultados",
                "info":         "Mostrando de _START_ até _END_ de _TOTAL_ registos",
                "infoEmpty":    "Mostrando de 0 até 0 de 0 registos",
                "infoFiltered": "(filtrado de _MAX_ registos no total)",
                "infoPostFix":  "",
                "search":       "Procurar:",
                "url":          "",
                "paginate": {
                    "first":    "Primeiro",
                    "previous": "Anterior",
                    "next":     "Seguinte",
                    "last":     "Último"
                }
            }
        });
    });
</script>

<?php 
    include('../components/footer.php');
?>