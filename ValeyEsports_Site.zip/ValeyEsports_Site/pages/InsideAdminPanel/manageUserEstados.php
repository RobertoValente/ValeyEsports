<?php
    include('../../scripts/Database/connect.php');
    include('../../scripts/ManageUser/verifyUserNotLog.php');
    include('../../scripts/ManageUser/verifyAdmNotLog.php');
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/manageUserEstados.css">
    <link rel="stylesheet" href="../../css/global.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAP - Roberto</title>

    <link href='../../Extras/DataTables/datatables.min.css' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="../../Extras/jquery-3.5.1.min.js"></script>
    <script type="text/javascript" src="../../Extras/DataTables/datatables.min.js"></script>
</head>

<?php 
    include('../components/nav.php');
?>

<body style="background-color: var(--bgColorMain); margin-bottom: 40px">
    <div class="bodyManageUserEstados">
        <h1 class="pageTitleManageUserEstados">Gerir Estado de Utilizadores:</h1>
        <div class="containerManageUserEstados">
            <table class="ManageUserEstadosTable" class="display dataTable">
                <thead>
                    <tr>
                        <th style="text-align: center;">Id</th>
                        <th style="text-align: center;">Estado</th>
                        <th style="text-align: center;">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $result = mysqli_query($ligaBD, "SELECT * FROM estadouser");
                        $row1Length = mysqli_num_rows($result);
                        while($row = mysqli_fetch_array($result)) {
                            echo "<tr>";
                                echo "<td style='text-align: center;'>". $row['id'] ."</td>";
                                echo "<td style='text-align: center;'>". $row['estado'] ."</td>";
                                echo "<td style='text-align: center;'>";
                                    echo "<a onclick='return confirm(`Tem certeza que deseja editar este estado?`);' href='./editUserEstado.php?idEstado=". $row['id'] ."'><img heiht=22 width=22 alt='Editar estado' title='Editar' src='../../images/edit.png'></a>";
                                    if(($row['id'] !== "0") and ($row['id'] !== "1") and ($row['id'] !== "3") and ($row['id'] !== "4")) {
                                        echo "     ";
                                        echo "<a onclick='return confirm(`Tem certeza que deseja eliminar este estado?`);' href='../../scripts/ManageUserEstados/delete.php?idEstado=". $row['id'] ."'><img heiht=22 width=22 alt='Eliminar estado' title='Eliminar' src='../../images/delete.png'></a>";
                                    }
                                echo "</td>";
                            echo "</tr>";
                        }
                    ?>
                </tbody>
            </table>
            <br>
            <form action="../../scripts/ManageUserEstados/create.php" method="POST">
                <input class="inputManageUserEstados" type="number" name="id" id="id" placeholder="Id" required>
                <input class="inputManageUserEstados" type="text" name="nome" id="nome" size="40" placeholder="Nome" required>
                <button class="buttonManageUserEstados">Criar Estado</button>
            </form>
        </div>
    </div>
</body>

<script>
    $(document).ready(function(){
        $('.ManageUserEstadosTable').DataTable({
            rowReorder: {
                selector: 'td:nth-child(4)'
            },
            responsive: true,
            "language": {
                "processing":   "A processar...",
                "lengthMenu":   "Mostrar _MENU_ registos",
                "zeroRecords":  "Não foram encontrados resultados",
                "info":         "Mostrando de _START_ até _END_ de _TOTAL_ registos",
                "infoEmpty":    "Mostrando de 0 até 0 de 0 registos",
                "infoFiltered": "(filtrado de _MAX_ registos no total)",
                "infoPostFix":  "",
                "search":       "Procurar:",
                "url":          "",
                "paginate": {
                    "first":    "Primeiro",
                    "previous": "Anterior",
                    "next":     "Seguinte",
                    "last":     "Último"
                }
            }
        });
    });
</script>

<?php 
    include('../components/footer.php');
?>