<?php
    include('../../scripts/Database/connect.php');
    include('../../scripts/ManageUser/verifyUserNotLog.php');
    include('../../scripts/ManageUser/verifyAdmNotLog.php');
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/manageRounds.css">
    <link rel="stylesheet" href="../../css/global.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAP - Roberto</title>

    <link href='../../Extras/DataTables/datatables.min.css' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="../../Extras/jquery-3.5.1.min.js"></script>
    <script type="text/javascript" src="../../Extras/DataTables/datatables.min.js"></script>
</head>

<?php 
    include('../components/nav.php');
?>

<body style="background-color: var(--bgColorMain); margin-bottom: 40px">
    <div class="bodyManageRounds">
        <h1 class="pageTitleManageRounds">Gestão de Partidas:</h1>
        <div class="containerManageRounds">
            <table class="ManageRoundsTable" class="display dataTable">
                <thead>
                    <tr>
                        <th style="text-align: center;">Nome do Torneio</th>
                        <th style="text-align: center;">Fase</th>
                        <th style="text-align: center;">Nº Partida</th>
                        <th style="text-align: center;">Jogador 1</th>
                        <th style="text-align: center;">Jogador 2</th>
                        <th style="text-align: center;">Vencedor</th>
                        <th style="text-align: center;">Estado da Partida</th>
                        <th style="text-align: center;">Data</th>
                        <th style="text-align: center;">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $result = mysqli_query($ligaBD, "SELECT torneios.nome, partidas.idpartida as partidaId, estadopartida.estado as partidaEstado, uv.nome as winner,  u1.nome as user1,  u2.nome as user2, partidas.data, partidas.idtorneio as torneioId, torneios.nMaxParticipantes as nMaxPlayers, partidas.idestado as partidaIdEstado, uv.id as userWinner, u1.id as userId1,  u2.id as userId2 FROM torneios, estadopartida, partidas LEFT JOIN users uv ON uv.id = partidas.vencedor  JOIN users u1  ON u1.id = partidas.iduser1  JOIN users u2  ON u2.id = partidas.iduser2  WHERE  partidas.idtorneio = torneios.id and torneios.id = partidas.idtorneio and estadopartida.id = partidas.idestado");
                        $row1Length = mysqli_num_rows($result);
                        while($row = mysqli_fetch_array($result)) {
                            echo "<tr>";
                                echo "<td style='text-align: center;'>". $row['nome'] ."</td>";
                                echo "<td style='text-align: center;'>". $row['partidaId'][0] ."</td>";
                                echo "<td style='text-align: center;'>". $row['partidaId'][1] ."</td>";
                                echo "<td style='text-align: center;'>". $row['user1'] ."</td>";
                                echo "<td style='text-align: center;'>". $row['user2'] ."</td>";
                                echo "<td style='text-align: center; color: #fff754;'>". $row['winner'] ."</td>";
                                echo "<td style='text-align: center;'>". $row['partidaEstado'] ."</td>";
                                echo "<td style='text-align: center;'>". $row['data'] ."</td>";
                                echo "<td style='text-align: center;'>";

                                    if($row['partidaIdEstado'] == 1) {
                                        echo "<a onclick='return confirm(`Tem certeza que deseja definir este jogador como vencedor da partida?`);' href='../../scripts/StartTournament/setWinner.php?idTorneio=". $row['torneioId'] ."&maxPlayers=". $row['nMaxPlayers'] ."&idPartida=". $row['partidaId'] ."&idPlayer=". $row['userId1'] ."&from=`ManageRounds`' pointer ><img heiht=22 width=22 alt='Definir Jogador 1 como Vencedor' title='Definir Jogador 1 como Vencedor' src='../../images/edit.png'></a>";
                                        echo "   ";
                                        echo "<a onclick='return confirm(`Tem certeza que deseja definir este jogador como vencedor da partida?`);' href='../../scripts/StartTournament/setWinner.php?idTorneio=". $row['torneioId'] ."&maxPlayers=". $row['nMaxPlayers'] ."&idPartida=". $row['partidaId'] ."&idPlayer=". $row['userId2'] ."&from=`ManageRounds`' pointer ><img heiht=22 width=22 alt='Definir Jogador 2 como Vencedor' title='Definir Jogador 2 como Vencedor' src='../../images/edit.png'></a>";
                                        
                                    }
                                    
                                echo "</td>";
                            echo "</tr>";
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

<script>
    $(document).ready(function(){
        $('.ManageRoundsTable').DataTable({
            rowReorder: {
                selector: 'td:nth-child(4)'
            },
            responsive: true,
            "language": {
                "processing":   "A processar...",
                "lengthMenu":   "Mostrar _MENU_ registos",
                "zeroRecords":  "Não foram encontrados resultados",
                "info":         "Mostrando de _START_ até _END_ de _TOTAL_ registos",
                "infoEmpty":    "Mostrando de 0 até 0 de 0 registos",
                "infoFiltered": "(filtrado de _MAX_ registos no total)",
                "infoPostFix":  "",
                "search":       "Procurar:",
                "url":          "",
                "paginate": {
                    "first":    "Primeiro",
                    "previous": "Anterior",
                    "next":     "Seguinte",
                    "last":     "Último"
                }
            }
        });
    });
</script>

<?php 
    include('../components/footer.php');
?>