<?php
    include('../../scripts/Database/connect.php');
    include('../../scripts/ManageUser/verifyUserNotLog.php');
    include('../../scripts/ManageUser/verifyAdmNotLog.php');
    if(!isset($_GET['idUser'])) {
        header("Location: ./manageUsers.php");
        exit();
    }
    $idToEdit = $_GET['idUser'];
    $query = "SELECT id, nome, email, idtipo, idestado from users where id = ". $idToEdit;
    $result = mysqli_query($ligaBD, $query);
    $row = mysqli_fetch_array($result);
?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/editUser.css">
    <link rel="stylesheet" href="../../css/global.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAP - Roberto</title>

    <link href='../../Extras/DataTables/datatables.min.css' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="../../Extras/jquery-3.5.1.min.js"></script>
    <script type="text/javascript" src="../../Extras/DataTables/datatables.min.js"></script>
</head>

<?php 
    include('../components/nav.php');
?>

<body style="background-color: var(--bgColorMain); margin-bottom: 40px">
    <div class="bodyEditUser">
        <h1 class="pageTitleEditUser">Editar Utilizador <?php echo $row[1]; ?>:</h1>
        <div class="containerEditUser">
            <form action="../../scripts/ManageUser/userUpdate.php">
                <label class="lblEditUser" for="id">ID:</label>
                <input class="inputEditUser" type="text" id="id" name="id" value="<?php echo $idToEdit; ?>" readOnly = "true"> <br>

                <label class="lblEditUser" for="name">Nome:</label>
                <input class="inputEditUser" type="text" id="name" name="name" value="<?php echo $row[1]; ?>"> <br>

                <label class="lblEditUser" for="email">Email:</label>
                <input class="inputEditUser" type="text" id="email" name="email" value="<?php echo $row[2]; ?>"> <br>

                <label class="lblEditUser" for="idtipo">Tipo de Utilizador:</label>
                <select class="selectEditUser" id="idtipo" name="idtipo" <?php if(($idToEdit == $_SESSION['userId']) and ($row[3] == 1)) echo "disabled"; ?>> <br>
                    <option <?php if($row[3] == 0) echo "selected = 'selected'" ?> value="0">Normal</option>
                    <option <?php if($row[3] == 1) echo "selected = 'selected'" ?> value="1">Administrador</option>
                </select> <br>

                <label class="lblEditUser" for="idestado">Estado do Utilizador:</label>
                <select class="selectEditUser" id="idestado" name="idestado" <?php if(($idToEdit == $_SESSION['userId']) and ($row[3] == 1)) echo "disabled"; ?>> <br>
                    <option <?php if($row[4] == 0) echo "selected = 'selected'" ?> value="0">Não Aprovado</option>
                    <option <?php if($row[4] == 1) echo "selected = 'selected'" ?> value="1">Registado</option>
                    <option <?php if($row[4] == 2) echo "selected = 'selected'" ?> value="2">Eliminado</option>
                    <option <?php if($row[4] == 3) echo "selected = 'selected'" ?> value="3">Banido</option>
                </select>
                <br> <br>
                <button class="btnEditUser" type="submit" onclick='return confirm(`Tem certeza que deseja alterar as informações deste utilizador?`);'>Guardar Informações</button>
            </form>
            <button class="btnEditUser" onclick="location.href='./manageUsers.php'">Cancelar</button>
        </div>
    </div>
</body>

<?php 
    include('../components/footer.php');
?>