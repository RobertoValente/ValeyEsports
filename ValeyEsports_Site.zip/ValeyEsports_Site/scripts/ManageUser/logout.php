<?php
    session_start();
    include('../Database/connect.php');
    
    $queryLoginUser = "INSERT INTO logs(iduser, idtipo) VALUES (". $_SESSION['userId'] .", 1)";
    mysqli_query($ligaBD, $queryLoginUser);
    session_destroy();

    header('Location: ../../pages/LandingPage/index.php');
    exit();
?>