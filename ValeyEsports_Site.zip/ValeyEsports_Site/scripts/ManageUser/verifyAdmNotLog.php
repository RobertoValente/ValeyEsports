<?php
	if(!($_SESSION['userIdTipo'] == 1)) {
		header('Location: ../../pages/AfterLogin/editProfile.php');
		exit();
	}
?>