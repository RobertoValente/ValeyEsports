<?php
	include('../Database/connect.php');
	$id = $_GET['idUser'];

	$queryGetPassword = "select password from users where id = ". $id;
    $resultGetPassword = mysqli_query($ligaBD, $queryGetPassword);
	$rowGPData = mysqli_fetch_row($resultGetPassword);

	$newPassword = $rowGPData[0]. "changed0000000000";
	echo $newPassword;

	$queryResetPassword = "UPDATE users set users.password = '". $newPassword ."' where users.id = ". $id;
    mysqli_query($ligaBD, $queryResetPassword);
	header("Location: ../../pages/InsideAdminPanel/manageUsers.php");
    exit();
?>