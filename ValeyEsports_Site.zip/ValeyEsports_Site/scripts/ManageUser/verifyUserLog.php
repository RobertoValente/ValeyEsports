<?php
	session_start();
	if(isset($_SESSION['userId'])) {
		header('Location: ../../pages/AfterLogin/editProfile.php');
		exit();
	}
?>