<?php
	session_start();
	include('../Database/connect.php');

	$email = trim($_POST['email']);
	$oldPassword = trim($_POST['oldPassword']);
	$pass = trim($_POST['password']);
	$passConfirm = trim($_POST['passwordConfirm']);

	$queryViewPassMD5 = "SELECT md5('{$oldPassword}')";
    $resultViewPassMD5 = mysqli_query($ligaBD, $queryViewPassMD5);
	$rowVPMData = mysqli_fetch_row($resultViewPassMD5);
    $passwordChanged = $rowVPMData[0]. "changed0000000000";
	$queryVerifyUser = "select nome from users where email LIKE '{$email}' and password LIKE '". $passwordChanged ."'";
    $resultVerifyUser = mysqli_query($ligaBD, $queryVerifyUser);
	$rowVULength = mysqli_num_rows($resultVerifyUser);

	if($pass == $passConfirm) {
		if($rowVULength == 1) {
			$queryResetPassword = "UPDATE users set password = md5('". $pass ."') where email = '". $email. "'";
			echo $queryResetPassword;
			mysqli_query($ligaBD, $queryResetPassword);
			$_SESSION['newPasswordSetted'] = true;
			header("Location: ../../pages/LandingPage/login.php");
			exit();
		} else {
			$_SESSION['emailOldPass_errado'] = true;
			header('Location: ../../pages/LandingPage/resetedPassword.php');
			exit();
		}
	} else {
		$_SESSION['differentPassword'] = true;
		header('Location: ../../pages/LandingPage/resetedPassword.php');
		exit();
	}
?>