<?php
	include('../Database/connect.php');
	$id = $_GET['idUser'];
	$querySetNotApproved = "DELETE FROM users where users.id = ". $id;
    mysqli_query($ligaBD, $querySetNotApproved);
	header("Location: ../../pages/InsideAdminPanel/aproveUsers.php");
    exit();
?>