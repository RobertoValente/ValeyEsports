<?php
	session_start();
	include('../Database/connect.php');

	if(empty($_POST['nome']) || empty($_POST['email']) || empty($_POST['password'])) {
		header('Location: ../../pages/LandingPage/registar.php');
		exit();
	}

	$nome = trim($_POST['nome']);
	$email = trim($_POST['email']);
	$password = trim($_POST['password']);

	$queryVerifyExistedEmail = "select * from users where email LIKE '{$email}'";
    $resultVerifyExistedEmail = mysqli_query($ligaBD, $queryVerifyExistedEmail);
	$rowVEEData = mysqli_fetch_row($resultVerifyExistedEmail);
	$rowVEELength = mysqli_num_rows($resultVerifyExistedEmail);

	if($rowVEELength == 0) {
		$queryRegisterUser = "insert into users(nome, email, password) values ('{$nome}', '{$email}', md5('{$password}'))";
		mysqli_query($ligaBD, $queryRegisterUser);
		$_SESSION['conta_criada'] = true;
		header('Location: ../../pages/LandingPage/login.php');
		exit();
	} else {
		$_SESSION['existe_email'] = true;
		header('Location: ../../pages/LandingPage/registar.php'); //TEM DE MANDAR PARA UMA PÁGINA A DIZER QUE NÃO FOI APROVADO
		exit();
	}

	
?>