<?php
	include('../Database/connect.php');
    session_start();
    $id = $_SESSION['userId'];
	$nome = $_POST['nome'];
    
    $query = "UPDATE users SET nome = '". $nome ."' where users.id = ". $id;
    mysqli_query($ligaBD, $query);
    header("Location: ../../pages/AfterLogin/editProfile.php");
    exit();
?>