<?php
	include('../Database/connect.php');
	$id = $_GET['id'];
    $nome = $_GET['name'];
    $email = $_GET['email'];

    if(isset($_GET['idtipo'])) {
        $idtipo = $_GET['idtipo'];
    } else {
        $idtipo = 1;
    }

    if(isset($_GET['idestado'])) {
        $idestado = $_GET['idestado'];
    } else {
        $idestado = 1;
    }
    
    $query = "UPDATE users SET nome = '{$nome}', email = '{$email}', idtipo = '{$idtipo}', idestado = '{$idestado}'where id = ". $id;
    mysqli_query($ligaBD, $query);
    header("Location: ../../pages/InsideAdminPanel/manageUsers.php");
    exit();
?>