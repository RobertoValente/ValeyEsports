<?php
	include('../Database/connect.php');
	$id = $_GET['idUser'];
	$querySetApproved = "UPDATE users set idestado = 3 where users.id = ". $id;
    mysqli_query($ligaBD, $querySetApproved);
	header("Location: ../../pages/InsideAdminPanel/manageUsers.php");
    exit();
?>