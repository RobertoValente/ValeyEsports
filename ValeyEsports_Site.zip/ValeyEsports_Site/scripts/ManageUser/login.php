<?php
    session_start();
    include('../Database/connect.php');

    if(empty($_POST['email']) || empty($_POST['password'])) {
        header('Location: ../../pages/LandingPage/index.php');
        exit();
    }

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $queryVerifyUser = "select idestado from users where email LIKE '{$email}'";
    $resultVerifyUser = mysqli_query($ligaBD, $queryVerifyUser);
	$rowVUData = mysqli_fetch_row($resultVerifyUser);
	$rowVULength = mysqli_num_rows($resultVerifyUser);

    if($rowVULength == 1) {
        //Verificar se está 'Não Aprovado'
        if($rowVUData[0] == 0) {
            $_SESSION['nao_aprovado'] = true;
            header('Location: ../../pages/LandingPage/login.php');
            exit();
        }

        //Verificar se está 'Banido'
        if($rowVUData[0] == 4) {
            $_SESSION['banido'] = true;
            header('Location: ../../pages/LandingPage/login.php');
            exit();
        }

        //Verificar se está 'Eliminado'
        if($rowVUData[0] == 3) {
            $_SESSION['eliminado'] = true;
            header('Location: ../../pages/LandingPage/login.php');
            exit();
        }

        // Verificar se a Password foi alterada por um Adminstrador
        $queryViewPassMD5 = "SELECT md5('{$password}')";
        $resultViewPassMD5 = mysqli_query($ligaBD, $queryViewPassMD5);
        $rowVPMData = mysqli_fetch_row($resultViewPassMD5);
        $passwordChanged = $rowVPMData[0]. "changed0000000000";
        $queryVerifyResetedPassword = "select * from users where email LIKE '{$email}' and password LIKE '{$passwordChanged}'";
        $resultVerifyResetedPassword = mysqli_query($ligaBD, $queryVerifyResetedPassword);
        $rowVRPLength = mysqli_num_rows($resultVerifyResetedPassword);

        if($rowVRPLength == 1) {
            header('Location: ../../pages/LandingPage/resetedPassword.php');
            exit();
        }

        $queryUserInfo = "select id, idtipo from users where email LIKE '{$email}' and password = md5('{$password}')";
        $resultUserInfo = mysqli_query($ligaBD, $queryUserInfo);
        $rowUIData = mysqli_fetch_row($resultUserInfo);
        $_SESSION['userId'] = $rowUIData[0];
        $_SESSION['userIdTipo'] = $rowUIData[1];

        $queryLoginUser = "INSERT INTO logs(iduser, idtipo) VALUES (". $rowUIData[0] .", 0)";
        mysqli_query($ligaBD, $queryLoginUser);

        header('Location: ../../pages/AfterLogin/editProfile.php');
		exit();
    } else {
        $_SESSION['nao_autenticado'] = true;
		header('Location: ../../pages/LandingPage/login.php');
		exit();
    }

?>