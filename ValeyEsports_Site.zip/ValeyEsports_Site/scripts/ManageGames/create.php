<?php
	include('../Database/connect.php');
	$jogo = $_POST['jogo'];
	$queryInsert = "INSERT INTO jogos (jogo) VALUES ('". $jogo ."')";

	try {
		mysqli_query($ligaBD, $queryInsert);
		header("Location: ../../pages/InsideAdminPanel/manageGames.php");
		exit();
	} catch (Exception $e) {
		header("Location: ../../pages/InsideAdminPanel/manageGames.php");
		exit();
	}
    
?>