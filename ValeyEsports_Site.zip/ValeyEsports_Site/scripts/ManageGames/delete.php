<?php
	include('../Database/connect.php');
	$id = $_GET['idEstado'];
	$queryDelete = "DELETE FROM estadouser where estadouser.id = ". $id;

    mysqli_query($ligaBD, $queryDelete);
	header("Location: ../../pages/InsideAdminPanel/manageUserEstados.php");
    exit();
?>