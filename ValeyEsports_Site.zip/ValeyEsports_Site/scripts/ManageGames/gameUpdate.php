<?php
	include('../Database/connect.php');
	$id = $_GET['id'];
    $jogo = $_GET['jogo'];
    
    $query = "UPDATE jogos SET jogo = '{$jogo}' where id = ". $id;
    mysqli_query($ligaBD, $query);
    header("Location: ../../pages/InsideAdminPanel/manageGames.php");
    exit();
?>