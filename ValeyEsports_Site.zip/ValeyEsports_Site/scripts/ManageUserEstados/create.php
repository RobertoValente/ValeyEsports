<?php
	include('../Database/connect.php');
	$id = $_POST['id'];
	$nome = $_POST['nome'];
	$queryInsert = "INSERT INTO estadouser (id, estado) VALUES (". $id .", '". $nome ."')";

	try {
		mysqli_query($ligaBD, $queryInsert);
		header("Location: ../../pages/InsideAdminPanel/manageUserEstados.php");
		exit();
	} catch (Exception $e) {
		header("Location: ../../pages/InsideAdminPanel/manageUserEstados.php");
		exit();
	}
    
?>