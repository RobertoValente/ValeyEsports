<?php
	include('../Database/connect.php');
	$id = $_GET['id'];
    $estado = $_GET['estado'];
    
    $query = "UPDATE estadouser SET estado = '{$estado}' where id = ". $id;
    mysqli_query($ligaBD, $query);
    header("Location: ../../pages/InsideAdminPanel/manageUserEstados.php");
    exit();
?>