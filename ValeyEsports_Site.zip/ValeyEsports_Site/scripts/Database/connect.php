<?php
    define('HOST','lhcp3331.webapps.net');
    define('USER','j65crs1a_Roberto');
    define('PASS','PAPFarm2023!');
    define('BD','j65crs1a_valeyesports');

    $ligaBD = mysqli_connect(HOST, USER, PASS, BD);
    $_SESSION['ligaBD'] = $ligaBD;

    if (mysqli_connect_errno()) {
        echo "Erro de ligação à base de dados" . mysqli_connect_error();
    }
?>