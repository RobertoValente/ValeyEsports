#!/usr/local/bin/php

<?php
    define('HOST','XXX');
    define('USER','XXX');
    define('PASS','XXX');
    define('BD','XXX');

    $ligaBD = mysqli_connect(HOST, USER, PASS, BD);

    if (php_sapi_name() === 'cli') {
        $tournamentId = $argv[1];
    } else {
        $tournamentId = $_GET['idTorneio'];
    }

    $queryMudarEstado = "UPDATE torneios SET idestado = 1 WHERE torneios.id = ". $tournamentId;
    mysqli_query($ligaBD, $queryMudarEstado);

    $queryGetPlayers = "SELECT participantes_torneio.iduser as userId, users.nome, torneios.nMaxParticipantes FROM participantes_torneio, users, torneios WHERE participantes_torneio.iduser = users.id and participantes_torneio.idtorneio = ". $tournamentId ." and torneios.id = ". $tournamentId; 
    $resultGetPlayers = mysqli_query($ligaBD, $queryGetPlayers);
    $rowGetPlayersLength = mysqli_num_rows($resultGetPlayers);

    if($rowGetPlayersLength == 0) {
        $query = "INSERT INTO participantes_torneio VALUES (". $tournamentId .", 1)"; 
        mysqli_query($ligaBD, $query);

        $queryGetPlayers = "SELECT participantes_torneio.iduser as userId, users.nome, torneios.nMaxParticipantes FROM participantes_torneio, users, torneios WHERE participantes_torneio.iduser = users.id and participantes_torneio.idtorneio = ". $tournamentId ." and torneios.id = ". $tournamentId; 
        $resultGetPlayers = mysqli_query($ligaBD, $queryGetPlayers);
        $rowGetPlayersLength = mysqli_num_rows($resultGetPlayers);
    }

    $players = array();
    while($row = mysqli_fetch_array($resultGetPlayers)) {
        array_push($players, $row['userId']);
        if(!isset($nPlayersMax)) {
            $nPlayersMax = $row['nMaxParticipantes'];
        }
    }

    $partida = "";
    $numPartida = 1;

    $nParesPossiveis = $nPlayersMax / 2;
    shuffle($players);
    $nPlayers = count($players);

    if ($nPlayers < $nParesPossiveis) {
        $nParesConcluidos = 0;
    } else {
        $nParesConcluidos = abs($nParesPossiveis - $nPlayers);
    }

    for ($c = 0; $c < $nParesConcluidos * 2; $c += 2) {
        $partida = "1". $numPartida;
        $intPartida = intval($partida);
        
        $queryInsertMatch = "INSERT INTO partidas (idpartida, idtorneio, iduser1, iduser2, idestado) VALUES ($intPartida, $tournamentId, {$players[$c]}, {$players[$c + 1]}, 1)";
        mysqli_query($ligaBD, $queryInsertMatch);

        $numPartida += 1;
    }
    
    // Parte para resolver os Pares com "Ghosts"
    $nParesLivres = $nParesPossiveis - $nParesConcluidos;
    $nPlayersLivres = count($players) - $nParesConcluidos * 2;
    
    for ($i = 0; $i < $nParesLivres; $i++) {
        if ($nPlayersLivres <= 0) {
            $partida = "1". $numPartida;
            $intPartida = intval($partida);

            $queryInsertMatch = "INSERT INTO partidas (idpartida, idtorneio, iduser1, iduser2, idestado) VALUES ($intPartida, $tournamentId, 1, 1, 1)";
            mysqli_query($ligaBD, $queryInsertMatch);

            $numPartida += 1;
        } else {
            $partida = "1". $numPartida;
            $intPartida = intval($partida);

            $queryInsertMatch = "INSERT INTO partidas (idpartida, idtorneio, iduser1, iduser2, idestado) VALUES ($intPartida, $tournamentId, {$players[count($players) - $nPlayersLivres]}, 1, 1)";
            mysqli_query($ligaBD, $queryInsertMatch);
            
            $nPlayersLivres--;
            $numPartida += 1;
        }
    }

    // ====== Tabela de MaxPlayers: 4
    if($nPlayersMax == 4) {
        $queryAddProximasFases = "INSERT INTO partidas (idpartida, idtorneio, iduser1, iduser2, idestado) VALUES (21, $tournamentId, 0, 0, 0)";
        mysqli_query($ligaBD, $queryAddProximasFases);
    }

    // ====== Tabela de MaxPlayers: 8
    if($nPlayersMax == 8) {
        $queryAddProximasFases = "INSERT INTO partidas (idpartida, idtorneio, iduser1, iduser2, idestado) VALUES (21, $tournamentId, 0, 0, 0), (22, $tournamentId, 0, 0, 0), (31, $tournamentId, 0, 0, 0)";
        mysqli_query($ligaBD, $queryAddProximasFases);
    }

    // ====== Tabela de MaxPlayers: 16
    if($nPlayersMax == 16) {
        $queryAddProximasFases = "INSERT INTO partidas (idpartida, idtorneio, iduser1, iduser2, idestado) VALUES (21, $tournamentId, 0, 0, 0), (22, $tournamentId, 0, 0, 0), (23, $tournamentId, 0, 0, 0), (24, $tournamentId, 0, 0, 0), (31, $tournamentId, 0, 0, 0), (32, $tournamentId, 0, 0, 0), (41, $tournamentId, 0, 0, 0)";
        mysqli_query($ligaBD, $queryAddProximasFases);
    }

    header("Location: ../../pages/InsideAdminPanel/manageTournaments.php");
	exit();
?>