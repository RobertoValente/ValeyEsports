<?php
	include('../Database/connect.php');
	$idTorneio = $_GET['idTorneio'];
    $maxPlayers = $_GET['maxPlayers'];
    $idPartida = $_GET['idPartida'];
    $idPlayer = $_GET['idPlayer'];
    if(isset($_GET['from'])) {
        $manageRoundPage = true;
    } else {
        $manageRoundPage = false;
    }

	$querySetWinner = "UPDATE partidas SET idestado = 2, vencedor = ". $idPlayer ." WHERE idtorneio = ". $idTorneio ." AND idpartida = ". $idPartida;
    mysqli_query($ligaBD, $querySetWinner);	
    
    if($maxPlayers == 4) { $nFases = 2;}
    if($maxPlayers == 8) { $nFases = 3;}
    if($maxPlayers == 16) { $nFases = 4;}
    $idFase = $idPartida[0];
    $idRonda = $idPartida[1];

    if($idFase == $nFases) {
        $querySetWinnerFinal = "UPDATE partidas, torneios SET partidas.idestado = 2, torneios.idestado = 2, partidas.vencedor = ". $idPlayer ." WHERE partidas.idtorneio = ". $idTorneio ." AND partidas.idpartida = ". $idPartida ." AND torneios.id = ". $idTorneio;
        mysqli_query($ligaBD, $querySetWinnerFinal);
        echo $maxPlayers ." / ". $nFases ." / ";
        if($manageRoundPage) {
            header("Location: ../../pages/InsideAdminPanel/manageRounds.php");
            exit();
        } else {
            header("Location: ../../pages/AfterLogin/manageTournament.php?tournament=". $idTorneio);
            exit();
        }
    } else {
        $proximaFase = $idFase + 1;
    }

    if($idRonda % 2 == 0){
        $proximaRonda = $idRonda / 2;
    }
    else{
        $proximaRonda = ($idRonda + 1) / 2;
    }

    $queryGetNextRound = "SELECT * FROM partidas WHERE idtorneio = ". $idTorneio ." AND idpartida = ". $proximaFase . $proximaRonda;
    $result = mysqli_query($ligaBD, $queryGetNextRound);	
    $row = mysqli_fetch_array($result);

    echo $maxPlayers ." / ". $nFases ." / ";
    echo $idPartida ." / ". $proximaFase ." / ". $proximaRonda;

    if($row['iduser1'] == 0) {
        $queryInsert = "UPDATE partidas SET iduser1 = ". $idPlayer ." WHERE idtorneio = ". $idTorneio ." AND idpartida = ". $proximaFase . $proximaRonda;
        mysqli_query($ligaBD, $queryInsert);
    } else {
        $queryInsert = "UPDATE partidas SET iduser2 = ". $idPlayer .", idestado = 1 WHERE idtorneio = ". $idTorneio ." AND idpartida = ". $proximaFase . $proximaRonda;
        mysqli_query($ligaBD, $queryInsert);
    }
    
    if($manageRoundPage) {
        header("Location: ../../pages/InsideAdminPanel/manageRounds.php");
        exit();
    } else {
        header("Location: ../../pages/AfterLogin/manageTournament.php?tournament=". $idTorneio);
        exit();
    }
?>