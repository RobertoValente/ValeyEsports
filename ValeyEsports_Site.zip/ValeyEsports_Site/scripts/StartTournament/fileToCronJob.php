#!/usr/local/bin/php

<?php
	define('HOST','XXX');
    define('USER','XX');
    define('PASS','XXX');
    define('BD','XXX');

    $ligaBD = mysqli_connect(HOST, USER, PASS, BD);
	
    $sql = "SELECT torneios.id FROM torneios WHERE torneios.dataInicio <= NOW() AND torneios.idestado = 0";
    $result = mysqli_query($ligaBD, $sql);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $idTournament = $row["id"];
            //file_get_contents("C:\xampp\htdocs\PAP\Site\scripts\StartTournament\begin.php?idTorneio=" . $idTournament);

            $command = "/usr/local/bin/php /home/j65crs1a/valeyEsports.farmconnect.pt/Site/scripts/StartTournament/begin.php ". $idTournament;
            $output = [];
            echo $command;
            exec($command, $output, $return_var);
        }
    }
?>