<?php
    include('../Database/connect.php');
    session_start();
    $tournamentId = $_POST['tournament'];
	$nome = $_POST['nome'];
    $descricao = $_POST['descricao'];

    if(implode($_FILES['image']) != 40) {
        $imagename = rand(1,1000000)."_".$_FILES['image']['name'];
        $imagetype = $_FILES['image']['type'];
        $imageerror = $_FILES['image']['error'];
        $imagetemp = $_FILES['image']['tmp_name'];

        $imagePath = "../../ImagensPAP/";

        if(is_uploaded_file($imagetemp)) {
            if(move_uploaded_file($imagetemp, $imagePath . $imagename)) {
                echo "Sussecfully uploaded your image.";
            }
        }

        $imagem = $imagePath.$imagename;
        $query = "UPDATE torneios SET imagem = '". $imagem ."' WHERE id = ". $tournamentId;
        mysqli_query($ligaBD, $query);
    }

    if((!isset($_POST['data'])) and (!isset($_POST['nMaxParticipantes'])) and (!isset($_POST['jogos']))) {
        $query = "UPDATE torneios SET nome = '{$nome}', descricao = '{$descricao}' WHERE torneios.id = ". $tournamentId; 
        mysqli_query($ligaBD, $query);
        header("Location: ../../pages/AfterLogin/tournamentsOverview.php");
        exit();
    } else {
        $data = $_POST['data'];
        $nMaxParticipantes = $_POST['nMaxParticipantes'];
        $jogo = $_POST['jogos'];
        
        $query = "UPDATE torneios SET nome = '{$nome}', descricao = '{$descricao}', dataInicio = '{$data}', nMaxParticipantes = '{$nMaxParticipantes}', idjogo = '{$jogo}' WHERE torneios.id = ". $tournamentId; 
        mysqli_query($ligaBD, $query);
        header("Location: ../../pages/AfterLogin/tournamentsOverview.php");
        exit();
    }
?>