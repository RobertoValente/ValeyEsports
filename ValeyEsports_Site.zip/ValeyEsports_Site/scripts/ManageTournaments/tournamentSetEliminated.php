<?php
	include('../Database/connect.php');
	$id = $_GET['tournament'];
	$querySetDeleted = "UPDATE torneios set idestado = 3 where torneios.id = ". $id;
    mysqli_query($ligaBD, $querySetDeleted);
	header("Location: ../../pages/AfterLogin/tournamentsOverview.php");
    exit();
?>