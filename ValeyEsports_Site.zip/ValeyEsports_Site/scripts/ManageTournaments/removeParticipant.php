<?php
    include('../Database/connect.php');
    session_start();
    $tournamentId = $_GET['idTournament'];
	$userId = $_GET['idUser'];
    
    $query = "DELETE FROM participantes_torneio WHERE idtorneio = ". $tournamentId ." and iduser = ". $userId; 
    mysqli_query($ligaBD, $query);
    header("Location: ../../pages/AfterLogin/tournamentsOverview.php");
    exit();
?>