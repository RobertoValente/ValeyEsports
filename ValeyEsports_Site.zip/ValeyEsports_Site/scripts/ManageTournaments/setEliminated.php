<?php
	include('../Database/connect.php');
	$id = $_GET['idTorneio'];

	$querySetEliminated = "UPDATE torneios set idestado = 3 where torneios.id = ". $id;
    mysqli_query($ligaBD, $querySetEliminated);
	header("Location: ../../pages/InsideAdminPanel/manageTournaments.php");
    exit();
?>