<?php
    include('../Database/connect.php');
    session_start();
    $tournamentId = $_GET['idTournament'];
	$userId = $_GET['idUser'];
    
    $query = "INSERT INTO participantes_torneio VALUES (". $tournamentId .", ". $userId .")"; 
    mysqli_query($ligaBD, $query);
    header("Location: ../../pages/AfterLogin/tournamentsOverview.php");
    exit();
?>