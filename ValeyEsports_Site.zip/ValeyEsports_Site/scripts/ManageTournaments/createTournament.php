<?php
    include('../Database/connect.php');
    session_start();
    $id = $_SESSION['userId'];
	$nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $data = $_POST['data'];
    $nMaxParticipantes = $_POST['nMaxParticipantes'];
    $jogo = $_POST['jogos'];

    $imagename = rand(1,1000000)."_".$_FILES['image']['name'];
    $imagetype = $_FILES['image']['type'];
    $imageerror = $_FILES['image']['error'];
    $imagetemp = $_FILES['image']['tmp_name'];

    $imagePath = "../../ImagensPAP/";

    if(is_uploaded_file($imagetemp)) {
        if(move_uploaded_file($imagetemp, $imagePath . $imagename)) {
            echo "Sussecfully uploaded your image.";
        }
        else {
            echo "Failed to move your image.";
        }
    }
    else {
        echo "Failed to upload your image.";
    }

    $imagem = $imagePath.$imagename;

    $query = "INSERT INTO torneios (idcriador, nome, descricao, imagem, nMaxParticipantes, dataInicio, idjogo) VALUES ('". $id ."', '". $nome ."', '". $descricao ."', '". $imagem ."', '". $nMaxParticipantes ."', '". $data ."', '". $jogo ."')";
    mysqli_query($ligaBD, $query);
    header("Location: ../../pages/AfterLogin/tournamentsOverview.php");
    exit();
?>