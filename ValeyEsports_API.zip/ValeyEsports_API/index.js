const path = require('path');
const express = require('express')
const app = express();
const mysql = require('mysql');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));


app.post('/tryLogin', function (req, res) {
    console.log(req.body)
    const dbAccess = mysql.createConnection({
        host: 'XXX',
        user: 'XXX',
        password: 'XXX',
        database: 'XXX'
    });
    dbAccess.connect();

    dbAccess.query(`SELECT users.id FROM users WHERE users.email = '${req.body.username}' AND users.password = MD5('${req.body.password}')`, function (error, results, fields) {
        if (error) throw error;
        if(results.length === 1) {
            dbAccess.end();
            console.log(results[0]);
            res.status(200).send({
                "idUser": results[0].id
            });
        } else {
            dbAccess.end();
            res.status(500).send();
        }
    });
});

app.post('/showTournaments', function (req, res) {
    console.log(req.body)
    const dbAccess = mysql.createConnection({
        host: 'XXX',
        user: 'XXX',
        password: 'XXX',
        database: 'XXX'
    });
    dbAccess.connect();

    dbAccess.query(`SELECT
  t.nome,
  CONCAT('https://valeyesports.farmconnect.pt/Site/ImagensPAP/', t.imagem) AS imagem,
  t.nMaxParticipantes,
  CASE
    WHEN t.dataInicio > CURRENT_DATE() THEN t.dataInicio
    ELSE ' '
  END AS dataInicio,
  et.estado AS estado,
  COUNT(pt.iduser) AS numParticipantes
FROM
  torneios t
  INNER JOIN participantes_torneio pt ON t.id = pt.idtorneio
  INNER JOIN estadotorneio et ON t.idestado = et.id
WHERE
  pt.iduser = ${req.body.idUser}
  AND t.idEstado <> 3
GROUP BY
  t.id,
  t.nome,
  t.nMaxParticipantes,
  dataInicio,
  estado`, async function (error, results, fields) {
        if (error) throw error;
        console.log(results)
        let dataa = parseToUtf8(results);
        console.log(dataa)
        dbAccess.end();
        res.status(200).send({
            "data": dataa
        });
    });
/*f
 if(results.length === 1) {
            res.status(200).send({
                "idUser": results[0].id
            });
            connection.end();
        } else {
            res.status(500).send({
                "idUser": 0
            });
            connection.end();
        }
*/
});

app.listen(3000);

function parseToUtf8(obj) {
  if (typeof obj === 'object' && obj !== null) {
    if (Array.isArray(obj)) {
      return obj.map(element => parseToUtf8(element));
    } else {
      const newObj = {};
      for (let key in obj) {
        if (obj.hasOwnProperty(key)) {
          newObj[parseToUtf8(key)] = parseToUtf8(obj[key]);
        }
      }
      return newObj;
    }
  } else if (typeof obj === 'string') {
    try {
      return decodeURIComponent(escape(obj));
    } catch (error) {
      // Ignore if already UTF-8 encoded or cannot be converted
    }
  }
  return obj;
}
